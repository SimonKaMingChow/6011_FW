

//#include "Econsense sys.h"

//*******************************************************************************
// pH or mV and temp count
//
//
//
//*******************************************************************************
//signed int v01=0;
float mv0=0;
float mv1000=0;
float mv2000=0;
int va1,vb1,vc1;
float Bate=3950;//3939.0
const float Coeff_d [20] =
{
  58440.0,  //-11.0��
  40600.7,  //    
  28931.4,
  20598.1,
  15149.8,
  12388.1,
  8779.0,
  6478.9,
  4669.9,
  3615.2,
  2683.5,
  2126.2,
  1587.1,
  1180.7,
  964.6,
  715.3,
  541.3,
  440.3,
  391.4,
  379.2
};
/*
//10K�¶ȵ���
const float Coeff_d [20] =
{
  58440.0,  
  40600.7,
  28931.4,
  20598.1,
  15149.8,
  12388.1,
  8779.0,
  6478.9,
  4669.9,
  3615.2,
  2683.5,
  2126.2,
  1587.1,
  1180.7,
  964.6,
  715.3,
  541.3,
  440.3,
  391.4,
  379.2
};

*/
const float Coeff_a [19] =
{ 21.5299148560,
  29.5374088287,
  37.6102790833,
  45.7022552490,
  52.3100814819,
  59.6544952393,
  68.7595596313,
  78.0952529907,
  87.1936111450,
  96.2222747803,
  105.1923599243,
  114.4910888672,
  125.4669723511,
  135.2654266357,
  145.8662109375,
  158.3292388916,
  169.4527282715,
  176.8995056152,
  181.6597290039
};
const float Coeff_b [19] =
{
  0.0008111311,
  0.0012059336,
  0.0017672763,
  0.0025522255,
  0.0034107820,
  0.0046371045,
  0.0067053791,
  0.0096136117,
  0.0134709030,
  0.0185361654,
  0.0251697917,
  0.0340527929,
  0.0479533635,
  0.0643203333,
  0.0867534056,
  0.1216494367,
  0.1623755842,
  0.1956660599,
  0.2197980732
};
const float Coeff_c [19] =
{
  0.0000000044,
  0.0000000092,
  0.0000000190,
  0.0000000381,
  0.0000000661,
  0.0000001173,
  0.0000002352,
  0.0000004624,
  0.0000008723,
  0.0000015843,
  0.0000028135,
  0.0000049391,
  0.0000093519,
  0.0000162005,
  0.0000280876,
  0.0000525774,
  0.0000899278,
  0.0001271717,
  0.0001577793
};
////////////////////////////////////////////////////////////////////////////////
void cound_mv(void)
{
  a1=(v%10000/1000)  ;
  a2=(v%1000/100)  ;
  a3=(v%100/10)  ;
  a4=(v%10)  ; 
  a5=(temp2%1000/100)  ;
  a6=(temp2%100/10)  ;
  a7=(temp2%10)  ;
  return ;
}
////////////////////////////////////////////////////////////////////////////////
int round_1(float x)                //��������
{
  float y,i;
  int k,l;
  i=x;
  if(x>=0)
    y=x+0.5;
  else y=x-0.5;
  l=(int)y; 
  if(i>0)
  {
    if(l>i)
      k=(int)(i+1);
    else k=(int)i;
  }
  else
  {
    if(l<i)
      k=(int)(i-1);
    else k=(int)i;
  }
  return(k);
}

////////////////////////////////////////////////////////////////////////////////
//*******************************************************************************
// mV ount
//
//******************************************************************************
void mV(void)
{ 
  float v6,v4,v5;
  signed int b;
 
    if(results[0]<=32768)
       v5=(mv_k1*results[0]+mv_b1); 
    else v5=(mv_k2*results[0]+mv_b2); 
     mv=round_1(v5);
     
    if(sys_mode ==MODE_AUTO_pH  || sys_mode ==MODE_pH )
    {
      if(cal==0 || cal==2)
     {
      if(point==0)
      {
        if(sys_mode ==MODE_AUTO_pH)
        {
           if(point>1)
          ph=(int)(ph2*100);
          else ph=(int)(ph1*100);
        }
        else
        {
        slope0=1.0;
        ph_offset0=0;
        }
       
      }
      else if(point==1)
      { slope0=slope1/1000.0;
        ph_offset0=ph_offset1;
       
      }
      else if(point==2)
      {
         slope0=slope2/1000.0;
        ph_offset0=ph_offset2;
      }
      else        
      {
        if(v_cal>=0)
        {
          if(mv>=0)
          { 
            slope0=slope2/1000.0;
            ph_offset0=ph_offset2;
          }
          else
          {
             slope0=slope3/1000.0;
             ph_offset0=ph_offset3;
          }
        }
        else
        {
          if(mv>=0)
          { 
            slope0=slope3/1000.0;
            ph_offset0=ph_offset3;
          }
          else
          {
             slope0=slope2/1000.0;
             ph_offset0=ph_offset2;
          }
        }
       
      }
        v6=((float)mv-ph_offset0)*1.0;
        v4=(temp1+2731.5)/10.0;
        v6=v6/v4/(slope0*(-0.19841))*10.0;
        v6=round_1(v6);
        ph=(int)(v6)+700;
      
    }
    else
    {
      
        if(sys_mode ==MODE_AUTO_pH  || sys_mode ==MODE_pH )
        {
          if(point>1)
          ph=(int)(ph2*100);
          else ph=(int)(ph1*100);
        }
        
        else ;
     /*   { 
         
            ph_offset0=0.0;
            slope0=1.0;           
          v6=((float)mv-ph_offset0)*1.0;
            v4=(temp1+2731.5)/10.0;
            v6=v6/v4/(slope0*(-0.19841))*10.0;
            v6=round_1(v6);
            ph=(int)(v6)+700;
        
        }*/
       }
    /*  else 
      {
         v6=((float)mv-ph_offset0)*1.0;
        v4=(temp1+2731.5)/10.0;
        v6=v6/v4/(slope0*(-0.19841))*10.0;
        v6=round_1(v6);
        ph=(int)(v6)+700;
      }*/
    }
    else ;
    if(sumd1==4)
    {
     /* if(sys_mode ==MODE_AUTO_pH  || sys_mode ==MODE_pH )
        va1=ph;
      else*/ va1=mv/10;
    }
    else ;
    if(sumd1==22)
    { 
     /* if(sys_mode ==MODE_AUTO_pH  || sys_mode ==MODE_pH )
        vc1=ph;
      else*/ vc1=mv/10;
      if(va1>=vc1-1 && va1<=vc1+1)
      {
        if(sys_mode ==MODE_AUTO_pH  || sys_mode ==MODE_AUTO_mV )
        {  hold=1;sumd1=21;
        }
        else 
        {
          hold=0;
          sumd1=0;
        }
      }
      else 
      {
        hold=0;
        sumd1=0;  
        /*if(sys_mode ==MODE_AUTO_pH  || sys_mode ==MODE_pH )
          va1=ph;
        else*/ va1=mv/10;
      }
      
    }
    else ;
  //  if(sumd1>=23)
 //       sumd1=0;
  //  else ;
    if(sys_mode ==MODE_AUTO_pH  || sys_mode ==MODE_pH )
    {
      if(ph>=0)
        v=ph;
      else v=ph*(-1);
          
    }
    else
    {
      error=0;
      b=mv/10;
      if(mv>0)
        v=b;
      else v=b*(-1);
    }   
    
  
 
  if(sys_mode ==MODE_AUTO_pH  || sys_mode ==MODE_pH )
  {
    if(ph>=-200 && ph<=1600)
      RANGE=0;
    else if(ph>1600)
      RANGE=1;
    else RANGE=2;
  }
  else 
  {
    if(mv<=19990 && mv>=-19990)
      RANGE=0;
    else if(mv>19990)
      RANGE=1;
    else RANGE=2;
  }
 return;
 
}
/*********************************************************************************/
void tempR(void)
{
  if(temp1>=-100 && temp1<=1200)
    RANGE_TEMP=0;
  else if(temp1<-100 )
    RANGE_TEMP=1;
  else RANGE_TEMP=2;
}
//******************************************************************************
void Temp(void)
{
  char y;
  float x,z,k;
  if(key_set==1)
  {    
    temp=set_i;    
  }
  else
  {
    if(results[1]>21000 || results[1]<10)
      atc=1;
    else
    { 
      /*//10K��������
      if((int)b_r1==0)
      {
        b_r1=10000.0;
        k_r1=500.0;
        b_r2=10000.0;
        k_r2=500.0;
      }*/
      
      //30K
      if((int)b_r1==0)
      {
        b_r1=30000.0;
        k_r1=1000.0;
        b_r2=30000.0;
        k_r2=1000.0;
      }
    x=(float)results[1];
    if(results[1]>=r10k)
      temp=x*b_r1/(k_r1-x);
    else temp=x*b_r2/(k_r2-x);
  /*
    x=log10(10000.0/temp);
    x=x/Bate;
    temp01=298.15*x/(x-298.15);
    temp1=temp01-273.15;*/
    y=0;
    while(1)
  {
    if(temp>58430.0)
    {
      atc=2;
      break;
    }
    if(temp<379.2)
    {
      atc=3;
      break;
    }
    atc=0;
    z=Coeff_d[y];
    k=Coeff_d[y+1];
    if(temp>=k && temp<=z)
      break;
    else y++;
  }
  

  value_a=Coeff_a[y];
  value_b=Coeff_b[y];
  value_c=Coeff_c[y]; 
    }
    if(atc==0)
    {
      temp01=((value_c*temp*temp-value_b*temp+value_a)*10);
      temp01=round_1(temp01);
      temp1=(int)temp01;
      
    }
    else if(atc==1)
      temp1=temp_man;
    else if(atc==2)
      temp1=-110;
    else if(atc==3)
      temp1=1300;
    else ;
    if(temp1>=0)
      temp2=temp1;
    else temp2=temp1*(-1);


  }
  tempR();
  return;
}


/***************************************************************************/
void Lobat()
{
  float x;
  int y;
  x=results[2]*1200.0/65536.0*4.95;
  y=(int)x;
  y=y*4-11360;
  if(y>5400)
    lobat=0;
  else if(y>5000 && y<=5400)
    lobat=1;
  else lobat=2;
  return;
  
}
//*****************************************************************************
void Count(void)
{ 
   Temp();
   mV();  
   Lobat();
  return;
}