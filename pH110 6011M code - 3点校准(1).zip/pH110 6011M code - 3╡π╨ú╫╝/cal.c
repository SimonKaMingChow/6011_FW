/*unsigned char tt;
float v1;
float v2;
float t1;
float t2;
float ph1;
float ph2;*/

//******************************************************************************/
/*const float pH4 [] =
{
  4.01,4.00,4.00,4.00,4.00,4.01,4.02,4.03,4.04,4.05,4.06,4.08,4.09
};
const float pH7 [] =
{
  7.10,7.07,7.04,7.02,7.00,6.98,6.98,6.98,6.98,6.98,6.98,6.99
};

const float pH101 [] =
{
  10.25,10.17,10.11,10.05,10.00,9.94,9.90,9.85,9.81,9.78,9.74,9.70,9.67
};
*/
//*****************************************************************************/


const signed int Coeff_t[15] = 
{ 0,25,75,125,175,225,275,325,375,425,475,525,575,600
};
/////////////////////////////////////////////////////////////////
const float pH_400 [13] =
{4.01,4.00,4.00,4.00,4.00,4.00,4.01,4.02,4.03,4.04,4.06,4.07,4.09};
const float pH_686 [13] =
{6.98,6.95,6.92,6.90,6.88,6.86,6.85,6.84,6.84,6.83,6.83,6.83,6.84};
const float pH_918 [13] =
{9.46,9.39,9.33,9.28,9.23,9.18,9.14,9.10,9.07,9.04,9.02,8.99,8.97};
const float pH_401 [13] =
{4.01,4.01,4.00,4.00,4.00,4.01,4.01,4.02,4.03,4.04,4.06,4.08,4.10};
const float pH_700 [13] =
{7.11,7.08,7.06,7.03,7.01,7.00,6.98,6.98,6.97,6.97,6.97,6.97,6.98};
const float pH_1001 [13] =
{10.32,10.25,10.18,10.12,10.06,10.01,9.97,9.93,9.89,9.86,9.83,9.80,9.78};

//////////////////////////////////////////////////////////////////////////////
void  Revise()
{ 
 
  if(point==1 ||point==0)
  {
  if(buff==0)
    {
      if(mv<=900 && mv>=-900)
      ph1=pH_700[tt];  
      else if(mv>900)
        ph1=pH_401[tt];
      else ph1=pH_1001[tt];
    }
    else
    {
     if(mv<=983 && mv>=-817)
      ph1=pH_686[tt];  
      else if(mv>983)
        ph1=pH_400[tt];
      else ph1=pH_918[tt];
     // ph1=pH_686[tt]; 
    }
 /*   if(buff==0)
     ph1=pH_700[tt];  
    else ph1=pH_686[tt];  */
  }
  if(point==2 )
  { 
     
   if(buff==0)
    {
      if(v2>1000.0)
         ph2=pH_401[tt];
      else  ph2=pH_1001[tt];     
    }
    else 
    { if(v2>1000.0)
         ph2=pH_400[tt];
      else  ph2=pH_918[tt];    
    }   
  }
  if(point==3)
  { 
     
   if(buff==0)
    {
      if(v3>1000.0)
         ph2=pH_401[tt];
      else  ph2=pH_1001[tt];     
    }
    else 
    { if(v3>1000.0)
         ph2=pH_400[tt];
      else  ph2=pH_918[tt];    
    }   
  }
 
  return;
}
/////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////
void Revise_temp()
{
 unsigned char x=0;
  float y,z; 
  while(1)
  {
    if(temp1>600.0)
    {
      x=12;
      break;
    }
    else if(temp1<0.0)
    {
      x=0;
      break;
    }
    else
    {
      y=Coeff_t[x];
      z=Coeff_t[x+1];
      if(temp1>=y && temp1<=z)
        break;
      else x++;
    }   
   
  }  
  tt=x;
  return;
  
}
//////////////////////////////////////////////////////////////////////////////////
void Slope()
 {   float i;
   if(point==1)
     slope0=-0.19841;
   if(point==2)  
     slope0=((v2-v1)/((ph2-7.00)*t2-(ph1-7.00)*t1))/10;
   if(point==3)
     slope0=((v3-v1)/((ph2-7.00)*t2-(ph1-7.00)*t1))/10;
  i=( slope0/(-0.19841))*1000; 
  if(i>=700 && i<=1300)        
  {
    if(point==1)
      slope1=i;
    else if(point==2)
      slope2=i;
    else  slope3=i;
    error=0;
  }
  else error=2;
  return;
 }
//////////////////////////////////////////////
void Phoffset()
{   if(point==2)
      ph_offset0=((((v2/10)*(ph1-7.00)*t1)-((v1/10)*(ph2-7.00)*t2))/(((ph1-7.00)*t1)-(ph2-7.00)*t2))*10;
   else if(point==3) 
    ph_offset0=((((v3/10)*(ph1-7.00)*t1)-((v1/10)*(ph2-7.00)*t2))/(((ph1-7.00)*t1)-(ph2-7.00)*t2))*10;
   else ;
  return;
}

//////////////////////////////////////////////////////////////////////////////
void Revise_slope()
{
  
    if(point==1)
    {     
      slope2=0.0;     
      ph_offset1=((v1/10)-((ph1-7.0)*(-0.19841)*t1))*10;    
      
    }
    else  if(point==2)
    {
      Phoffset();
      ph_offset2= ph_offset0;
      
    }
    else
    { Phoffset();
      ph_offset3= ph_offset0;
    }
  return;
}
//////////////////////////////////////////////////////////////////////////////////
void  Cal1()
{  if(temp1>600.0 || temp1<0.0)
       error=3;
     else error=0;
     
 
 if(point<2)
 {
   slope1=0.0;
   slope2=0.0;
   slope3=0.0;ph_offset1=0.0;ph_offset2=0.0;ph_offset3=0.0;
   if(buff==0)
   { if(error==0)
  {
      if(mv>900 && mv<=1100) // if(mv>2400.0 || mv<-2400.0)//if(mv>900.0 || mv<-900.0)
           error=1;
         else if(mv<-900 && mv>=-1100)
           error=1;
         else if(mv>2600.0)
           error=1;
         else if(mv<-2600.0)
           error=1;
     else error=0;
  }
  else ;
   }
   else
   { if(error==0)
  {
      if(mv>983 && mv<=1100)// if(mv>2400.0 || mv<-2400.0)//if(mv>900.0 || mv<-900.0)
           error=1;
         //else if(mv<-900 && mv>=-1100)
          // error=1;
         else if(mv>2600.0)
           error=1;
         else if(mv<-1900.0)
           error=1;
     else  error=0;
   }
   
   else ;
   }
} 
 
 if(point==1)
 { 
  
   v1=mv; 
   t1=temp1/10+273.15;
 } 
 else if(point==2)
 {
    v2=mv; 
  //  v_cal=mv;
    t2=temp1/10+273.15; 
    Revise_temp();
    Revise();
    if(error==0)
      Slope();
   else ;
 }
 else
 {  v3=mv; 
    t2=temp1/10+273.15; 
    Revise_temp();
    Revise();//Slope();
    if(v3>=0 && v2>0)
      error=2;
    else if(v3<=0 && v2<0)  
      error=2; 
    else error=0;
   if(error==0)
     Slope();
   else ;
 }
 if(error==0)
 {
   clear=0;
   Revise_temp();
   Revise();
  // if(point>0)
   //{
     if(hold==1)
     {
       if(point==1)
       { 
         v1=mv; 
         t1=temp1/10+273.15;
       }
       else  if(point==2)
       {
         v2=mv;   v_cal=mv;
         t2=temp1/10+273.15;
       }
       else
       {
         v3=mv; 
         t2=temp1/10+273.15;
       }
       Slope();
       Revise_slope();       
       
         measing=0;
         if(point==3)
         {
           cal_ok=1;
           cal=0;
         }
         else
         {
           if(point==1)
           {
           if(buff==0)
           {
           if(mv<=900.0 && mv>=-900.0)cal=2;
           else 
           {
             cal_ok=1;
           cal=0;
           }
           }
           else
           {
             if(mv<=983.0 && mv>=-817.0)cal=2;
              else 
           {
             cal_ok=1;
           cal=0;
           }
           }
           
           }
           else cal=2;
         }
       
         
       //if(point==3) 
       //  {
      //   if(error==0)
     //      cal=0;
      //   else ;//}
       //  else ;
      Savedata_a(); 
      _BUZ_ON;
      Delay1();
      _BUZ_OFF; //key_set1=1;
     }
     else ;
 //  }
 //  else ;
 }     
 else ;//clear=1;
 return;
}
//////////////////////////////////////////////////////////////////////////////////////












