/******************************************************************************/
//�ļ�����Econsense pH.h
//��  �ã��궨�壬��������
//******************************************************************************/
#include <msp430x42x.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
//***************define*******************
//deifne lcd******************************
/*
#define  SEG_AUTO        LCDMEM+11,BIT0
#define  SEG_CAL         LCDMEM+11,BIT1
#define  SEG_F           LCDMEM+11,BIT2
#define  SEG_C           LCDMEM+11,BIT3
#define  SEG_STAND       LCDMEM+11,BIT4
#define  SEG_MAN         LCDMEM+11,BIT5
#define  SEG_SLOPE       LCDMEM+11,BIT6
#define  SEG_ATC         LCDMEM+11,BIT7

#define  SEG_pH          LCDMEM+10,BIT0
#define  SEG_Delete      LCDMEM+10,BIT1
#define  SEG_All         LCDMEM+10,BIT2
#define  SEG_Each        LCDMEM+10,BIT3
#define  SEG_do          LCDMEM+10,BIT4     //%
#define  SEG_ppm         LCDMEM+10,BIT5
#define  SEG_mBar        LCDMEM+10,BIT6  
#define  SEG_mV          LCDMEM+10,BIT7

#define  SEG_P1          LCDMEM+9,BIT0
#define  SEG_P2          LCDMEM+8,BIT0
#define  SEG_P3          LCDMEM+7,BIT0
#define  SEG_BAR1        LCDMEM+6,BIT0
#define  SEG_BAR2        LCDMEM+5,BIT0
#define  SEG_7BC         LCDMEM+4,BIT0
#define  SEG_BAT         LCDMEM+3,BIT0
#define  SEG_P4          LCDMEM+2,BIT0

#define  SEG_EFF         LCDMEM,BIT7
#define  SEG_Save        LCDMEM,BIT6
#define  SEG_Full        LCDMEM,BIT5
#define  SEG_Recall      LCDMEM,BIT4
#define  SEG_WAIT        LCDMEM,BIT2
#define  SEG_HOLD        LCDMEM,BIT1
#define  SEG_SAL_ppt     LCDMEM,BIT0
*/

//deifne io*********************************************************************

//P1����ֵ
/*
#define  KEY_POWER     1                       //���� ON/OFF
#define  KEY_STAND     2                       //���� STAND
#define  KEY_SLOPE     4                       //���� SLOPE
#define  KEY_CLEAR     8                       //���� CLEAR
#define  KEY_MODE      0                       //���� MODE
#define  KEY_UP        20                       //���� UP
#define  KEY_DOWN      40                       //���� DOWN
#define  KEY_MEAS      80                       //���� MEAS
#define  KEY_SET       0                      //�������ö�·��

//���ƶ˿ڶ���******************************************************************
#define  CTR_SET       BIT0          ////contre port
#define  CTR_SHD       BIT1          ////contre port
#define  CTR_BUZ       BIT3          ////contre port*/
#define  CTR_PORT_OUT  P2OUT         ////contre port output
//��������**********************************************************************
#define  KEY_CLR_TIM   10            //CLR������Ӧ��Ҫ��ʱ��  
#define  KEY_POW_TIM   15            //���ػ�������Ӧʱ��

//���ƶ˿ڿ���******************************************************************
#define  _BUZ_OFF       CTR_PORT_OUT &= ~BIT3      // low level off
#define  _BUZ_ON        CTR_PORT_OUT |=  BIT3      //high level on
//***********************�궨�壺***********************************************
#define  uint   unsigned int
#define  uchar  unsigned char
//mode****************************************************************
//if Econsens pH define
#define  MODE_AUTO_pH         0                  //AUTO pH
#define  MODE_AUTO_mV         1                  //AUTO mV
#define  MODE_pH              2                  //pH     
#define  MODE_mV              3                  //mV
#define  MODE_RECALL          4                  //RECALL
#define  MODE_DELETE          5                  //ɾ��ģʽ
#define  MODE_SAVE            6                  //SAVE
#define  MODE_CAL             7                  //У��ģʽ
#define  MODE_SET             8                  //��������
#define  MODE_OFF             9                  //�ػ�ģʽ
/////////////////////////////////////////////////////////////////////////////
//**********************ȫ�ֱ�����**********************************************
//ϵͳ��־
uchar sys_mode = 0;    //ϵͳ��ǰģʽ
uchar mode_save = 0;   //ϵͳģʽ����
uint  autoff = 0;      //�Զ��ػ�����  
uchar hold = 0;        //hold������CLR���ּ���
uchar power = 0;       // = 1�ػ�״̬ 
uchar measing = 0;     // = 0���ڲ���,1�ؽ�ģʽ��2ɾ��ģʽ��3saveģʽ��4У׼ģʽ��5��������ģʽ��6�ػ�ģʽ
uchar cal = 0;        // = 1����У׼
uchar clear = 0;     // = 1���У׼ֵ
uchar delte = 0;     // = 1���У׼ֵ
char  set_i = 0;       //����������
char  set_ok = 0;      //�����������ȶ���MODE��



//����
uchar key_v = 0;        //��ֵ  ��ʶ
uchar key_r = 0;        //�����ͷű�־
//value
uchar time=0;
uchar RANGE=0;                         //0��ʾPH,MV�ڷ�Χ֮�ڣ�1����Χ����,2����Χ����
uchar RANGE_TEMP=0;                    //0��ʾTEMP�ڷ�Χ֮�ڣ�1����Χ����,2����Χ����
uchar point=0;
uchar buff=0;
uchar ph4=0;
uchar ph7=0;
uchar ph10=0;
uchar ph401=0;
uchar ph686=0;
uchar ph918=0;
uchar error=0;
uchar recal=0;
uchar mode=0;
uchar tt=0;
uchar each=1;                  //0��ʾEach��1��ʾall
uchar lobat;                  //0��ʾ��ص�ѹ������1��ʾ��ѹ�ͣ�2��ʾû�е�
unsigned char sumd1=0;       //WAIT��ʾ����
unsigned char sumd2=0;       //MAN�¶� UP AND DOWN����
unsigned char sumd3=0;       //�洢������0~24
signed char sumd5=0;       //deleteʱ��
signed char sumd6=0;       //eff% ʱ��
signed char sumd7=0;       //1��ʾmeas���Ѱ���
unsigned char key=0;
unsigned char sign=0;
unsigned char atc=0;
unsigned char key_set=0;
unsigned char key_set1=0;
unsigned char cal_ok=0;unsigned char ai=0;
//signed char sumd=0; 
unsigned char full=0;       //0��ʾû�д洢�� 1��ʾ�洢��
long signed int sumd=0;       //�洢������
long signed int sumd4=0;       //recall����
long unsigned int results[3];
long signed int mv=0;;
long signed int v=0;
long signed int ph=0;
long signed int a1=0;
long signed int a2=0;
long signed int a3=0;
long signed int a4=0;
long signed int a5=0;
long signed int a6=0;
long signed int a7=0;
long signed int temp_man=250;
long signed int temp1;
long signed int temp2;
long signed int v_bat;
float value_a;
float value_b;
float value_c;
float temp01;
float temp=0.0;
float slope0=0.0;
//float slope01=0.0;
float slope1=0.0;
float slope2=0.0;
float slope3=0.0;
float ph_offset0=0.0;
float ph_offset1=0.0;
float ph_offset2=0.0;
float ph_offset3=0.0;
float v1;
float v2;
float v3;
float v_cal;
float t1;
float t2;
float ph1;
float ph2;
void Readdata_a(void);  void Readdata_b(void);  
void Savedata_a();
void Count(void);
void Adc(void);void Lobat();void mV(void);
/*

uchar clear1=0;
uchar setup1=0;
uchar evr=0;
uchar clear0=0;
uchar key1=0;
uchar mv_cal=0;
uchar ph_cal=0;
uchar f_cal=0;
uchar error=0;
uchar ph1=0;
uchar ph2=0;
uchar ph3=0;
uchar ph4=0;
uchar ph6=0;
uchar ph7=0;
uchar ph8=0;
uchar ph10=0;
uchar ph101=0;
uchar ph12=0;
uchar ph13=0;
uchar ph168=0;
uchar ph401=0;
uchar ph686=0;
uchar ph918=0;
uchar ph1246=0;
uchar index14=0;
uchar index12=0;
uchar index04=0;
uchar index01=0;
uchar point=0;
uchar cal0=0;
uchar cal01=0;
uchar cal02=0;
uchar atc=0;
uchar sign_t=0;
uchar index22=0;
uint temp1=0;
uint temp2=0;

float v1=0.0;
float v2=0.0;
float v3=0.0;
float v4=0.0;
float v5=0.0;
float v6=0.0;
float vt1=0.0;
float vt2=0.0;
float vt3=0.0;
float vt4=0.0;
float vt5=0.0;
float vt6=0.0;
float temp=0.0;
float calv1=0.0;
float calv2=0.0;
float calv3=0.0;
float slope0=0.0;
float calv4=0.0;
float calv5=0.0;
float calv6=0.0;
float calv7=0.0;
float cv1=0.0;
float cv2=0.0;
float slope1=0.0;
float slope2=0.0;
float slope3=0.0;
float t1=0.0;
float t2=0.0;
float ph_offset0=0.0;
float ph_offset1=0.0;
float ph_offset2=0.0;
float ph_offset3=0.0;
float rev_v0=0.0;
float rev_v1=0.0;
float rev_v2=0.0;

*/






