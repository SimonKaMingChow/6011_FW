 /*int v_data[50];
 int temp_data[50];
 int sumd_data[50] ; 
 int mode_data[50] ; */
float r30k=0;
float r10k=0;
float r1k=0; 
float mv_k1=0;
float mv_b1=0; 
float mv_k2=0;
float mv_b2=0;
float k_r1=0;
float b_r1=0;
float k_r2=0;
float b_r2=0;
///////////////////////////////////////////////////////////////////////////////

void delteall(void)                           //
{/*
   char i,j=0,*flash_ptr;     
   flash_ptr = (char *)0xfa00;    
   FCTL1 = FWKEY +ERASE;                          //����FLASH��   
   FCTL3 = FWKEY; 
   flash_ptr = 0;                           //��������  
   FCTL1 = FWKEY +WRT;  
   flash_ptr = (int *)0xfa00;
   FCTL1 = FWKEY;
   FCTL3 = FWKEY +LOCK;
   flash_ptr = (char *)0xfc00;  
   FCTL1 = FWKEY +ERASE;                          //����FLASH��   
   FCTL3 = FWKEY; 
   flash_ptr = 0; 
   FCTL1 = FWKEY +WRT; 
  flash_ptr = (int *)0xfc00;
   FCTL1 = FWKEY;
   FCTL3 = FWKEY +LOCK;*/
   
  int *flash_ptr;
  flash_ptr = (int *)0xfa00;                   //д���    
  FCTL1 = FWKEY +ERASE;                           //����FLASH��    
  FCTL3 = FWKEY;
  *flash_ptr = 0;                           //��������
  FCTL1 = FWKEY +WRT;   
  flash_ptr = (int *)0xfa00;
  FCTL1 = FWKEY;
  FCTL3 = FWKEY +LOCK;
  flash_ptr = (int *)0xfc00;                   //д���    
  FCTL1 = FWKEY +ERASE;                           //����FLASH��    
  FCTL3 = FWKEY;
  *flash_ptr = 0;                           //��������
  FCTL1 = FWKEY +WRT;   
  flash_ptr = (int *)0xfc00; 
  FCTL1 = FWKEY;
  FCTL3 = FWKEY +LOCK; 
  flash_ptr = (int *)0xfD00;                   //д���    
  FCTL1 = FWKEY +ERASE;                           //����FLASH��    
  FCTL3 = FWKEY;
  *flash_ptr = 0;                           //��������
  FCTL1 = FWKEY +WRT;   
  flash_ptr = (int *)0xfD00;
  FCTL1 = FWKEY;
  FCTL3 = FWKEY +LOCK; 
 
  return;
}
//==============================================================================
void Readdata_a(void)                           //���������������
{
   
     float *flash_ptr; 
   flash_ptr = 0; 
   flash_ptr = (float*)0x1000;
   ph_offset1 = *flash_ptr++;
   slope1= *flash_ptr++;
   ph_offset2 = *flash_ptr++;
   slope2= *flash_ptr++;
   ph_offset3 = *flash_ptr++;
   slope3= *flash_ptr++;
   temp_man=(int) *flash_ptr++;
   point=(char) *flash_ptr++;
   buff= (char)*flash_ptr++; 
   measing=(char)*flash_ptr++ ;
   sys_mode=(char)*flash_ptr++ ;
   //sumd=(char)*flash_ptr++;  
   v1= *flash_ptr++;
   ph1=*flash_ptr++;  
   sumd7=(char)*flash_ptr++; 
   cal_ok=(char)*flash_ptr++;
   cal=(char)*flash_ptr++;
   v3=*flash_ptr++;
   v_cal=*flash_ptr++;
   v1=*flash_ptr++;
   ph1=*flash_ptr++;
   return;
}//==============================================================================
void Readdata_b(void)                           //���������������
{
   
     float *flash_ptr; 
   flash_ptr = 0; 
   flash_ptr = (float*)0x1000;
   ph_offset1 = *flash_ptr++;
   slope1= *flash_ptr++;
   ph_offset2 = *flash_ptr++;
   slope2= *flash_ptr++;
   ph_offset3 = *flash_ptr++;
   slope3= *flash_ptr++;
   (int) *flash_ptr++;
   point=(char) *flash_ptr++;
   buff= (char)*flash_ptr++; 
   measing=(char)*flash_ptr++ ;
   sys_mode=(char)*flash_ptr++ ;
   //sumd=(char)*flash_ptr++;  
   v1= *flash_ptr++;
   ph1=*flash_ptr++;  
   sumd7=(char)*flash_ptr++; 
   cal_ok=(char)*flash_ptr++;
   cal=(char)*flash_ptr++;
   v3=*flash_ptr++;
   v_cal=*flash_ptr++;
   v1=*flash_ptr++;
   ph1=*flash_ptr++;
   return;
}
//======================================================================================
void Savedata_a()
{  float *flash_ptr; 
   flash_ptr = (float *)0x1000;    
   FCTL1 = FWKEY +ERASE;                          //����FLASH��   
   FCTL3 = FWKEY;
   *flash_ptr = 0.0;                                 //��������
   FCTL1 = FWKEY +WRT;  
   flash_ptr = (float*)0x1000;
   *flash_ptr++= ph_offset1;
   *flash_ptr++= slope1;
   *flash_ptr++= ph_offset2;
   *flash_ptr++= slope2;
   *flash_ptr++= ph_offset3;
   *flash_ptr++= slope3;
   *flash_ptr++= temp_man;
   *flash_ptr++= point;
   *flash_ptr++= buff;
   *flash_ptr++= measing;
   *flash_ptr++ = sys_mode;
  // *flash_ptr++ =sumd;
   *flash_ptr++ =v2;
   *flash_ptr++ =ph2;
   *flash_ptr++ = sumd7;
   *flash_ptr++=cal_ok; 
   *flash_ptr++=cal;
   *flash_ptr++=v3;
   *flash_ptr++=v_cal;
   *flash_ptr++=v1;
   *flash_ptr++=ph1;
   FCTL1 = FWKEY;
   FCTL3 = FWKEY +LOCK;
  
   return;
}
//================================================================================
void Copy_a2b()
{
   signed int *flash_ptra; 
   signed int *flash_ptrb; 
   unsigned int i;
   flash_ptra = (int *)0xf800;                //д���  
   flash_ptrb = (int *)0xfa00;                //д���  
   FCTL1 = FWKEY +ERASE;                           //����FLASH��  
   FCTL3 = FWKEY;
   *flash_ptra = 0;                           //��������  
   FCTL1 = FWKEY +WRT;  
   for(i=0;i<512;i++)
   {
     *flash_ptra ++ =*flash_ptrb++;
   } 
   FCTL1 = FWKEY;
   FCTL3 = FWKEY +LOCK; 
   return;
}
///////////////////////////////////////////////////////////////////////////////
void Copy_a2bchar()
{
   char *flash_ptra; 
   char *flash_ptrb; 
   unsigned int i;
   flash_ptra = (char *)0xf800;                //д���  
   flash_ptrb = (char *)0xfc00;                //д���  
   FCTL1 = FWKEY +ERASE;                           //����FLASH��  
   FCTL3 = FWKEY;
   *flash_ptra = 0;                           //��������  
   FCTL1 = FWKEY +WRT;  
   for(i=0;i<512;i++)
   {
     *flash_ptra ++ =*flash_ptrb++;*flash_ptra ++ =*flash_ptrb++;*flash_ptra ++ =*flash_ptrb++;
   } 
   FCTL1 = FWKEY;
   FCTL3 = FWKEY +LOCK; 
   return;
}
/*
///////////////////////////////////////////////////////////////////////////////////////
void Savedatb()
{ 

}

/////////////////////////////////////////////////////////////////////////////////////
void Savedata()
{ 



}*/

//================================================================================
void Savedatb()
{  
  unsigned char i;
  char *flash_ptr1,*flash_ptr2,*flash_ptr3;
  //signed int va,vb;
  signed int *flash_ptr,*flash_ptra,*flash_ptrb;   
  Copy_a2b();
  flash_ptr = (int *)0xfa00;                //д���     
  flash_ptra = (int *)0xf800;                //д���         
  FCTL1 = FWKEY +ERASE;                     //����FLASH��    
  FCTL3 = FWKEY;
  *flash_ptr = 0; 
  *flash_ptra = 0;  
  FCTL1 = FWKEY +WRT;   //��������   
  for(i=0;i<=sumd;i++)
  {
    if(i>=sumd4)
    {
      if(i==sumd4)
        flash_ptra++;
      else ;
      *flash_ptr ++ =*flash_ptra++;
    }
    else *flash_ptr ++ =*flash_ptra++;
  } 
  flash_ptrb = (int *)0xf900;                //д���      
  flash_ptr = (int *)0xfb00;                //д��� 
  for(i=0;i<=sumd;i++)
  {
    if(i>=sumd4)
      {
      if(i==sumd4)
        flash_ptrb++;
      else ;
      *flash_ptr ++ =*flash_ptrb++;
    } 
    else *flash_ptr ++ =*flash_ptrb++;
  }  
  FCTL1 = FWKEY;
  FCTL3 = FWKEY +LOCK;
  Copy_a2bchar();
  flash_ptr1 = (char *)0xfc00;                //д���  
  flash_ptr2 = (char *)0xf800;                 //д��� 
  FCTL1 = FWKEY +ERASE;                           //����FLASH��                 
  FCTL3 = FWKEY;
  *flash_ptr1 = 0;                           //��������  
  FCTL1 = FWKEY +WRT;     
  for(i=0;i<=sumd;i++)
  {
    if(i>=sumd4)
    {
      if(i==sumd4)
        flash_ptr2++;
      else ;
      *flash_ptr1 ++ =*flash_ptr2++; 
    }
    else *flash_ptr1 ++ =*flash_ptr2++;
  }  
  flash_ptr3 = (char *)0xf864;                 //д��� 
  flash_ptr1 = (char *)0xfc64;                //д��� 
  for(i=0;i<=sumd;i++)
  {
    if(i>=sumd4)
    {
     
      if(i==sumd4)
      {
        flash_ptr3++;flash_ptr3++;flash_ptr3++;
      }
      else ;
      {
        *flash_ptr1 ++ =*flash_ptr3++;*flash_ptr1 ++ =*flash_ptr3++;*flash_ptr1 ++ =*flash_ptr3++;
      }
    }
    else
    {
      *flash_ptr1 ++ =*flash_ptr3++;*flash_ptr1 ++ =*flash_ptr3++;*flash_ptr1 ++ =*flash_ptr3++;
    }
  }  
  flash_ptr1 = (char *)0xfcff;                //д���   
  *flash_ptr1 =(sumd-1);
  FCTL1 = FWKEY;
  FCTL3 = FWKEY +LOCK; 
  return;
}
//================================================================================
void Savedata()
{  
  unsigned char i,j,k,l;
  char *flash_ptr1,*flash_ptr2,*flash_ptr3;
  signed int va,vb;
  int *flash_ptr,*flash_ptra,*flash_ptrb;   
  sumd3=sumd;
  if(sumd==0xff)
    ;
  else Copy_a2b();
  flash_ptr = (int *)0xfa00;                //д���     
  flash_ptra = (int *)0xf800;                //д���         
  FCTL1 = FWKEY +ERASE;                           //����FLASH��    
  FCTL3 = FWKEY;
  *flash_ptr = 0; 
  *flash_ptra = 0;  
  FCTL1 = FWKEY +WRT;   //��������   
  if(sys_mode==MODE_pH || sys_mode==MODE_AUTO_pH  )
    va=ph;
  else va=mv/10;   
  vb=temp1;
  j=sumd;  
  k=sys_mode;
  l=atc;   
  for(i=0;i<=sumd3;i++)
  {
    if(i==sumd3)
      *flash_ptr ++ =va;
    else *flash_ptr ++ =*flash_ptra++;
  } 
  flash_ptrb = (int *)0xf900;                //д���      
  flash_ptr = (int *)0xfb00;                //д��� 
  for(i=0;i<=sumd3;i++)
  {
    if(i==sumd3)
      *flash_ptr++ =vb;
    else *flash_ptr ++ =*flash_ptrb++;
  }  
  FCTL1 = FWKEY;
  FCTL3 = FWKEY +LOCK;
  if(sumd==0)
    ;
  else Copy_a2bchar();
  flash_ptr1 = (char *)0xfc00;                //д���  
  flash_ptr2 = (char *)0xf800;                 //д��� 
  FCTL1 = FWKEY +ERASE;                           //����FLASH��                 
  FCTL3 = FWKEY;
  *flash_ptr1 = 0;                           //��������  
  FCTL1 = FWKEY +WRT;     
  for(i=0;i<=sumd3;i++)
  {
    if(i==sumd3)
      *flash_ptr1++ =k;  
    else *flash_ptr1 ++ =*flash_ptr2++;
  }  
  flash_ptr3 = (char *)0xf864;                 //д��� 
  flash_ptr1 = (char *)0xfc64;                //д��� 
  for(i=0;i<=sumd3;i++)
  {
    if(i==sumd3)
    {   
      *flash_ptr1++ =l;  
      *flash_ptr1++ =buff;
      *flash_ptr1++ =point;
    }
    else 
    {
      *flash_ptr1 ++ =*flash_ptr3++; 
      *flash_ptr1 ++ =*flash_ptr3++;
      *flash_ptr1 ++ =*flash_ptr3++;
    }
  }   
  flash_ptr1 = (char *)0xfcff;                //д���   
  *flash_ptr1 =j;
  FCTL1 = FWKEY;
  FCTL3 = FWKEY +LOCK; 
  sumd++;
 // sumd3++;
  return;
}
////////////////////////////////////////////////////////////////////////////////

void Savedata_set()
{ 
   float *flash_ptr; 
   flash_ptr = (float *)0x1080;    
   FCTL1 = FWKEY +ERASE;                          //����FLASH��   
   FCTL3 = FWKEY;
   *flash_ptr = 0.0;                                 //��������
   FCTL1 = FWKEY +WRT;  
   flash_ptr = (float*)0x1080;
   *flash_ptr++= mv_k1;
   *flash_ptr++= mv_b1;
   *flash_ptr++= mv_k2;
   *flash_ptr++= mv_b2;
   *flash_ptr++= k_r1;
   *flash_ptr++= b_r1;
   *flash_ptr++= k_r2;
   *flash_ptr++= b_r2;
   *flash_ptr++= r10k;  
   *flash_ptr++= r1k;  
   FCTL1 = FWKEY;
   FCTL3 = FWKEY +LOCK;
   return;
}
//===============================================================================
void Readdata_set(void)                           //���������������
{
   
   float *flash_ptr; 
   flash_ptr = 0; 
   flash_ptr = (float*)0x1080;
   mv_k1 = *flash_ptr++;
   mv_b1= *flash_ptr++;
   mv_k2= *flash_ptr++;
   mv_b2= *flash_ptr++;
   k_r1= *flash_ptr++;
   b_r1= *flash_ptr++;
   k_r2= *flash_ptr++;
   b_r2= *flash_ptr++;
   r10k= *flash_ptr++;  
   r1k= *flash_ptr++; 
   return;
}

//===============================================================================


//==================================================================================
void sys(void)
{
  char *flash_ptr4;
  WDTCTL    = WDTPW + WDTHOLD;       //�ع�
  FLL_CTL0 |= XCAP14PF;              //���þ������
  SCFQCTL   = SCFQ_4M;               //����ʱ��Ƶ��  
  P1DIR &= 0Xff;                             //�������ŷ������� p1.0~p1.7
  P1IES = 0xff;                             //�½����ж�     
 // P1IE |= 0Xff;
  P1IFG = 0;  
  P2DIR = 0X0E; 
  P2OUT = 0X02;  
  LCDCTL = LCDON + LCD4MUX + LCDP1;
  BTCTL  = BTFRFQ1;
  SD16CTL   = SD16REFON + SD16SSEL_0;   //SD16VMIDON +   // 1.2V ref, SMCLK  ��׼�����ⲿ
 // SD16INCTL1 = SD16GAIN_1;
  SD16CCTL0 = SD16GRP;             // Single conv, group with CH1
  SD16CCTL1 = SD16GRP+SD16DF;             // Single conv, group with CH2
  SD16CCTL2 = SD16IE;              // Single conv, enable interrupt
  temp_man = 250;
  temp=0.0;
  set_ok=1;
  Readdata_set();
  Readdata_a();
  flash_ptr4 = (char*)0xfcff;//0xfcc8;
  sumd = (char)*flash_ptr4++;
  if(sumd==0xff)
  {
    sumd=1;
    sumd3=1;
  }
  else sumd++;
  if(temp_man<=-1000)
    temp_man=250;
  else ;    
 key_set=0;
 if(point==0)
   cal_ok=0;
 else cal_ok=1;
   cal=0;
//   measing=0;
// else ;
  return;
}
////////////////////////////////////////////////////////////////////////////////////





