
////////////////////////////////////////////////////////////////////////////////

unsigned char index4=1;
///////////////////////////////////////////////////////////////////////////////
void enter_clear(void)
{
  //Flash_clr((int *)0x1011);
  
  if(clear1==1)
  {
    if(ph==1)
    {
      ph_cal=0; 
      cal01=0;
      cal0=0; 
      cal01=0;
      point=0;
    }
    else
    {
      v02=0;
      mv_cal=0;  
      cal0=0;
    }
  }
  ph1=0;
  ph2=0;
  ph3=0;
  ph4=0;
  ph6=0;
  ph7=0;
  ph8=0;
  ph10=0;
  ph101=0;
  ph12=0;
  ph13=0;
  ph168=0;
  ph401=0;
  ph686=0;
  ph918=0;
  ph1246=0;
}
///////////////////////////////////////////////////////////////////////////////
void enter(void)
{
  if(cal0 !=0)
    hold=1;
  else 
  {
  if(clear1==1)
    enter_clear(); 
  else if(clear1==2)
    ;
  else if(clear1==3)
    ;
  else if(clear1==4)
    cal02=1;
  else if(clear1==5)
    cal02=2;
  else if(clear1==6)
    cal02=3;
  else ;
   clear1=0;
    index4=0;
  }
  return;
}
////////////////////////////////////////////////////////////////////////////////
void mv_ph(void)
{
  if(ph==1)
    ph=2;
  else ph=1;
  return;  
}
////////////////////////////////////////////////////////////////////////////////
void setup(void)
{  

  if(index4==1)
   {
     clear1=1;     
     if(ph==1)
     {
       if(ph_cal==1)
       {
         if(point==0)
          {
            clear1=4;
            index4=4;
          }
         else ;
       }
       else  
       {
         clear1=4;
         index4=4;      
       }
     }
     else
     {
       if(mv_cal==1)
       {
         clear1=1;
         index4=0;
       }
       else 
       {
         index4=0;
         clear1=0;
       }
     }
  }  
  else if(index4==2)
  {
    if(point>1)
      clear1=2;
    else 
    {
      clear1=4;
      index4=4; 
    }   
  } 
  else if(index4==3)
  { 
    if(point==3)
      clear1=3;
    else 
    {
      clear1=4;
      index4=4; 
    }
  }
  else if(index4==4)
    clear1=4;
   else if(index4==5)
    clear1=5;
   else if(index4==6)
    clear1=6;  
   else if(index4==7)
    clear1=7;    
  else ;
  if(clear1==7)
  {
    clear1=0;
    index4=0;
  }
  else ;
  index4++;
  return;
}
////////////////////////////////////////////////////////////////////////////////
void cal(void)
{  
  index12=0;
  if(cal0==0)
    index01=0;
  else ;
  cal01=1;
  if(ph==1)
  {
    
    cal0=1;
    if(slope1 !=0)
    {
      if(slope2 !=0)
      {
        if(slope3!=0)
          point++;
        else point=3;
      }
      else point=2;
      
    }
    else point=1;
    
    if(point==4)
    {
      point=1;   
      enter_clear();
    }
  }
  else cal0=2;
  return;
}
////////////////////////////////////////////////////////////////////////////////
void key(void)
{
  if(clear0==1 || evr==1)
    ;
  else
  {
  if(cal0==0)
  {
  if(key1==4)
    enter();
  else if(key1==1)
    mv_ph();
  else if(key1==2)
    setup();
  else if(key1==3)
    cal();
  else if(key1==5)
  {
    evr=1;
    key1=0;
  }
  else if(key1==6)
  {
    clear0=1;
    key1=0;
  }
  else ;
  }
  else
  {
    if(key1==4)
    enter();
    else ;
  }
  }
  key1=0;
  return;
}
////////////////////////////////////////////////////////////////////////////////







