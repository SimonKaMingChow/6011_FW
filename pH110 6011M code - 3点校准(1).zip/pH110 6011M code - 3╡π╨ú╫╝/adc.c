#define  ADCH_CON  SD16MEM2
#define  ADCH_TEM  SD16MEM1
#define  ADCH_BAT  SD16MEM0

#define  ADC_I        8                           //ÿ�βɼ� ADת������

unsigned char adc_i = 0;                          //ad ת������
long unsigned int ad_con_ch[ADC_I]={0};           //mV �ɼ�ֵ                 
long unsigned int ad_tem_ch[ADC_I]={0};           //�¶ȡ�������
long unsigned int ad_bat_ch[ADC_I]={0};           //��ء�������
//------------------------------------------------------------------------------
//��������InitAD
//��  �ã���ʼ��AD
//��  ע����ͨ�����βɼ�  �ڲ���׼ �������ⲿ
//------------------------------------------------------------------------------
/*void InitAdc(void)
{ 
  SD16CTL   = SD16REFON + SD16VMIDON + SD16SSEL0;      // 1.2V ref, SMCLK  ��׼�����ⲿ
  //SD16INCTL1 = SD16GAIN_16;
  SD16CCTL0 = SD16GRP;             // Single conv, group with CH1
  SD16CCTL1 = SD16GRP;             // Single conv, group with CH2
  SD16CCTL2 = SD16IE;              // Single conv, enable interrupt
}

*/
//------------------------------------------------------------------------------
//��������ADCRD     ADC REZULT DEAL
//��  �ã�ADת��������� ���Ĵ�ƽ��ֵ
//------------------------------------------------------------------------------
void AdcRD(void)
{
 long int x = 0.0; 
  
  x =  ad_con_ch[3] + ad_con_ch[4] + ad_con_ch[5] + ad_con_ch[6]+ ad_con_ch[7];
  results[0] = x/5;
  x =   ad_tem_ch[3] + ad_tem_ch[4] + ad_tem_ch[5] + ad_tem_ch[6] + ad_tem_ch[7]   ; 
  results[1] = x/5;
  results[2] = (ad_bat_ch[6]+ad_bat_ch[7])/2;
  return;
}

//------------------------------------------------------------------------------
//��������ADConv
//��  �ã�����AD����ת��
//------------------------------------------------------------------------------
void Adc(void)
{
  adc_i = 0;
  SD16CCTL2 |= SD16SC;          // Set bit to start conversion  
  LPM0;                         // Enter LPM0
  SD16CCTL2 &= ~SD16SC;         // Set bit to over conversion
  AdcRD();
}


//------------------------------------------------------------------------------
//��������ADC interrupt
//��  �ã�AD�ж�
//------------------------------------------------------------------------------
#pragma vector=SD16_VECTOR 
__interrupt void SD16ISR(void)
{
 switch (SD16IV)
  {
  case 2:                                   // SD16MEM Overflow
    break;
  case 4:                                   // SD16MEM0 IFG
    break;
  case 6:                                   // SD16MEM1 IFG
    break;
  case 8:                                   // SD16MEM2 IFG
    ad_bat_ch[adc_i] = ADCH_BAT;               // Save CH0 results (clears IFG)
    ad_tem_ch[adc_i] = ADCH_TEM;               // Save CH1 results (clears IFG)
    ad_con_ch[adc_i] = ADCH_CON;               // Save CH2 results (clears IFG)

    adc_i++;
    break;
  }
   if(adc_i == ADC_I)
   {
      _BIC_SR_IRQ(LPM0_bits);           // Exit LPM0
   }
 return;
}
