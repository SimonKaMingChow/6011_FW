//6011M LCD
//deifne lcdseg*****************************************************************
//deifne lcd******************************
#define  SEG_AUTO        LCDMEM+2,BIT7
#define  SEG_CAL         LCDMEM+4,BIT7
#define  SEG_F           LCDMEM+5,BIT4
#define  SEG_C           LCDMEM+11,BIT4
#define  SEG_MAN         LCDMEM+3,BIT7
#define  SEG_700         LCDMEM+11,BIT6 //7.00//#define  SEG_SLOPE       LCDMEM+11,BIT7 //7.00
#define  SEG_401         LCDMEM+11,BIT7  //4.00#define  SEG_STAND       LCDMEM+11,BIT6  //4.00
#define  SEG_1001        LCDMEM+11,BIT5  //10.01

#define  SEG_686         LCDMEM+11,BIT2 //7.00//#define  SEG_SLOPE       LCDMEM+11,BIT7 //7.00
#define  SEG_918         LCDMEM+5,BIT5
#define  SEG_400         LCDMEM+11,BIT3  //4.00#define  SEG_STAND       LCDMEM+11,BIT6  //4.00

#define  SEG_ATC         LCDMEM+1,BIT7
#define  SEG_pH          LCDMEM+10,BIT4
#define  SEG_Delete      LCDMEM+5,BIT7
#define  SEG_All         LCDMEM+5,BIT2
#define  SEG_Each        LCDMEM+5,BIT3
#define  SEG_do          LCDMEM+10,BIT7     //%
//#define  SEG_ppm         LCDMEM+10,BIT6   //mg/L
//#define  SEG_mBar        LCDMEM+11,BIT3  
#define  SEG_mV          LCDMEM+10,BIT5
#define  SEG_P1          LCDMEM+7,BIT7
#define  SEG_P2          LCDMEM+8,BIT7
#define  SEG_P3          LCDMEM+9,BIT7
#define  SEG_BAR1        LCDMEM+10,BIT3
#define  SEG_BAR2        LCDMEM+11,BIT0
#define  SEG_7BC         LCDMEM+11,BIT1  //D1
#define  SEG_BAT         LCDMEM+10,BIT1
#define  SEG_P4          LCDMEM,BIT7
//#define  SEG_SAL_gL      LCDMEM+5,BIT4
//#define  SEG_hPa         LCDMEM+11,BIT2

#define  SEG_EFF         LCDMEM+5,BIT6
#define  SEG_Save        LCDMEM+10,BIT0
#define  SEG_Full        LCDMEM+5,BIT1
#define  SEG_Recall      LCDMEM+5,BIT0
#define  SEG_WAIT        LCDMEM+6,BIT7
#define  SEG_HOLD        LCDMEM+10,BIT2
//#define  SEG_SAL_ppt     LCDMEM+5,BIT5
//deifne function***************************************************************
#define  _LCDALL          ClrLcd(0XFF)        //show  all seg
#define  _LCDCLR          ClrLcd(0X00)        //clear all seg 
#define  _LCDMCLR         DisplayMClr()
//#define  _LCDNCLR         DisplayNCLR()
#define  _LCDMOFF         DisplayMOff()
#define  _LCDMSAVE        DisplayMSave()
#define  _LCDMOVER        DisplayMOver()
#define  _LCDMUNDR        DisplayMUndr()
#define  _LCDMERR         DisplayMERR()
#define  _LCDNOVER        DisplayNOver()
#define  _LCDNUNDR        DisplayNUnder()

//����������********************************************************************
const char digit[22] =
{ 
  0x5f,   //'0' 0   a+b+c+d+e+f
  0x06,   //'1' 1   b+c
  0x6b,   //'2' 2   a+b+d+e+g
  0x2f,   //'3' 3   a+b+c+d+g
  0x36,   //'4' 4   b+c+f+g
  0x3d,   //'5' 5   a+c+d+f+g
  0x7d,   //'6' 6   a+c+d+e+f+g
  0x07,   //'7' 7   a+b+c 
  0x7f,   //'8' 8   a+b+c+d+e+f+g
  0x3f,   //'9' 9   a+b+c+d+f+g
  0x77,   //'a' 10  a+b+c+e+f+g
  0x7c,   //'b' 11  c+d+e+f+g
  0x59,   //'c' 12  a+b+c+d
  0x6e,   //'d' 13  b+c+d+e+g
  0x79,   //'e' 14  a+d+e+f+g
  0x71,   //'f' 15  a+e+f+g
  0x58,   //'l' 16  d+e+f
  0x64,   //'n' 17  c+e+g
  0x6c,   //'o' 18  c+d+e+g
  0x60,   //'r' 19  e+g
  0x4c,   //'u' 20  c+d+e
  
  0x00    //00  21

};


/*
//6010M LCD
//deifne lcdseg*****************************************************************
//deifne lcd******************************
#define  SEG_AUTO        LCDMEM+11,BIT0
#define  SEG_CAL         LCDMEM+11,BIT1
#define  SEG_F           LCDMEM+11,BIT2
#define  SEG_C           LCDMEM+11,BIT3
#define  SEG_STAND       LCDMEM+11,BIT4
#define  SEG_MAN         LCDMEM+11,BIT5
#define  SEG_SLOPE       LCDMEM+11,BIT6
#define  SEG_ATC         LCDMEM+11,BIT7

#define  SEG_pH          LCDMEM+10,BIT0
#define  SEG_Delete      LCDMEM+10,BIT1
#define  SEG_All         LCDMEM+10,BIT2
#define  SEG_Each        LCDMEM+10,BIT3
#define  SEG_do          LCDMEM+10,BIT4     //%
#define  SEG_ppm         LCDMEM+10,BIT5
#define  SEG_mBar        LCDMEM+10,BIT6  
#define  SEG_mV          LCDMEM+10,BIT7

#define  SEG_P1          LCDMEM+9,BIT0
#define  SEG_P2          LCDMEM+8,BIT0
#define  SEG_P3          LCDMEM+7,BIT0
#define  SEG_BAR1        LCDMEM+6,BIT0
#define  SEG_BAR2        LCDMEM+5,BIT0
#define  SEG_7BC         LCDMEM+4,BIT0
#define  SEG_BAT         LCDMEM+3,BIT0
#define  SEG_P4          LCDMEM+2,BIT0

#define  SEG_EFF        LCDMEM,BIT7
#define  SEG_Save        LCDMEM,BIT6
#define  SEG_Full        LCDMEM,BIT5
#define  SEG_Recall      LCDMEM,BIT4
#define  SEG_WAIT        LCDMEM,BIT2
#define  SEG_HOLD        LCDMEM,BIT1
#define  SEG_SAL_ppt     LCDMEM,BIT0

//deifne function***************************************************************
#define  _LCDALL          ClrLcd(0XFF)        //show  all seg
#define  _LCDCLR          ClrLcd(0X00)        //clear all seg 
#define  _LCDMCLR         DisplayMClr()
//#define  _LCDNCLR         DisplayNCLR()
#define  _LCDMOFF         DisplayMOff()
#define  _LCDMSAVE        DisplayMSave()
#define  _LCDMOVER        DisplayMOver()
#define  _LCDMUNDR        DisplayMUndr()
#define  _LCDMERR         DisplayMERR()
#define  _LCDNOVER        DisplayNOver()
#define  _LCDNUNDR        DisplayNUnder()

//����������********************************************************************
const char digit[22] =
{ 
  0xbe,   //'0' 0   a+b+c+d+e+f
  0x06,   //'1' 1   b+c
  0x7c,   //'2' 2   a+b+d+e+g
  0x5e,   //'3' 3   a+b+c+d+g
  0xc6,   //'4' 4   b+c+f+g
  0xda,   //'5' 5   a+c+d+f+g
  0xfa,   //'6' 6   a+c+d+e+f+g
  0x0e,   //'7' 7   a+b+c 
  0xfe,   //'8' 8   a+b+c+d+e+f+g
  0xde,   //'9' 9   a+b+c+d+f+g
  0xee,   //'a' 10  a+b+c+e+f+g
  0xf2,   //'b' 11  c+d+e+f+g
  0xb8,   //'c' 12  a+b+c+d
  0x76,   //'d' 13  b+c+d+e+g
  0xf8,   //'e' 14  a+d+e+f+g
  0xe8,   //'f' 15  a+e+f+g
  0xb0,   //'l' 16  d+e+f
  0x62,   //'n' 17  c+e+g
  0x72,   //'o' 18  c+d+e+g
  0x60,   //'r' 19  e+g
  0x32,   //'u' 20  c+d+e
  
  0x00    //00  21

};*/
//�������**********************************************************************
char lcd_i= 0;  //������ʾ����
char lcd_j= 0;  //������ʾ����
char lcd_k= 0;  //������ʾ����
//==============================================================================
//��������InitLCD
//��  �ã�LCD��ʼ��
//==============================================================================
//////////////////////////////////////////////////////////////////////////////////

void BSET(char * address, unsigned char bit)     //��λ
{
    *address|=bit;
}
//////////////////////////////////////////////////////////////////////////////////////////
void BCLR(char * address,unsigned char bit)      //����
{
    *address&=(~bit);
}

///////////////////////////////////////////////////////////////////////////////////////
///==============================================================================
//��������ClrLCD
//��  �ã����LCD j=0  ȫ��LCD j=0xff
//==============================================================================
void ClrLcd(char j)
{
   unsigned char i;
   for(i=0;i<12;i++)
   {
      LCDMEM[i]=j;
     // BCLR(SEG_SAL_ppt);
      //BCLR(SEG_mBar);
     // BCLR(SEG_ppm);
     // BCLR(SEG_do);
           
   }
   return;
}
//------------------------------------------------------------------------------
//��������DisplayCLE
//��  �ã�����ʾ����ʾrcl
//------------------------------------------------------------------------------
/*void DisplayCLE(void)
{
    LCDMEM[4]=0; //   ��
    LCDMEM[5]=0;  //         ��
    return;
}*/
//------------------------------------------------------------------------------
//��������DisplayNO
//��  �ã�����ʾ����ʾnonE
//------------------------------------------------------------------------------
void DisplayNO(void)
{
    LCDMEM[6]=digit[17];; //  n
    LCDMEM[7]=digit[18];  //  o
    LCDMEM[8]=digit[17]; //  n 
    LCDMEM[9]=digit[14];//  E
    return;
}
//------------------------------------------------------------------------------
//��������DisplayRCL
//��  �ã�����ʾ����ʾrcl
//------------------------------------------------------------------------------
void DisplayRCL(void)
{
    LCDMEM[6]=0;//       ��
    LCDMEM[7]=digit[19]; //  r
    LCDMEM[8]=digit[12];  //  c
    LCDMEM[9]=digit[16]; //  l
    return;
}
//------------------------------------------------------------------------------
//��������DisplayRCL
//��  �ã�����ʾ����ʾrcl
//------------------------------------------------------------------------------
void DisplayDEL(void)
{
    LCDMEM[6]=0;//       �� 
    LCDMEM[7]=digit[13];//  d  
    LCDMEM[8]=digit[14];//  E
    LCDMEM[9]=digit[16];//  L
    return;
}

//------------------------------------------------------------------------------
//��������DisplayMOver
//��  �ã�����ʾ����ʾOVER
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
void DisplayTempMOver(void)
{
  
    LCDMEM[2]=digit[18]; //  0
    LCDMEM[1]=digit[20];//  v
    LCDMEM[0]=digit[19];//  r
    return;
}
//------------------------------------------------------------------------------
//��������DisplayMUNDR
//��  �ã�����ʾ����ʾOVER
//------------------------------------------------------------------------------
void DisplayTempMUndr(void)
{
 
    LCDMEM[2]=digit[20];//  u
    LCDMEM[1]=digit[13];//  d
    LCDMEM[0]=digit[19];//  r
    return;
}
void DisplayMOver(void)
{
    LCDMEM[6]=digit[18]; //  o
    LCDMEM[7]=digit[20];//  v
    LCDMEM[8]=digit[14];//  e
    LCDMEM[9]=digit[19];//  r
    return;
}
//------------------------------------------------------------------------------
//��������DisplayMUNDR
//��  �ã�����ʾ����ʾOVER
//------------------------------------------------------------------------------
void DisplayMUndr(void)
{
    LCDMEM[6]=digit[20];//  u
    LCDMEM[7]=digit[17];//  n
    LCDMEM[8]=digit[13];//  d
    LCDMEM[9]=digit[19];//  r
    return;
}
//------------------------------------------------------------------------------
//��������DisplayMOff
//��  �ã�����ʾ����ʾOff
//------------------------------------------------------------------------------
void DisplayMOff(void)
{
    LCDMEM[6]=0;        //  ��  
    LCDMEM[7]=digit[0]; //  o
    LCDMEM[8]=digit[15];//  f
    LCDMEM[9]=digit[15];//  f  
    return;
     
}
//------------------------------------------------------------------------------
//��������DisplayMSave
//��  �ã�����ʾ����ʾSAVE
//------------------------------------------------------------------------------
void DisplayMSave(void)
{
    LCDMEM[6]=digit[5]; //  s    
    LCDMEM[7]=digit[10];//  a
    LCDMEM[8]=digit[20];//  v
    LCDMEM[9]=digit[14];//  e    
    return;  
}

//------------------------------------------------------------------------------
//��������DisplayMERR
//��  �ã�����ʾ����ʾerr
//------------------------------------------------------------------------------
void DisplayMERR1(void)
{
    LCDMEM[6]=0;//     //  �� 
    LCDMEM[7]=digit[14];//  e
    LCDMEM[8]=digit[19];//  r
    LCDMEM[9]=digit[1];;//  1    
    return; 
}
void DisplayMERR2(void)
{
    LCDMEM[6]=0;//     //  �� 
    LCDMEM[7]=digit[14];//  e
    LCDMEM[8]=digit[19];//  r
    LCDMEM[9]=digit[2];;//  2   
    return;  
}
void DisplayMERR3(void)
{
    LCDMEM[6]=0;//     //  �� 
    LCDMEM[7]=digit[14];//  e
    LCDMEM[8]=digit[19];//  r
    LCDMEM[9]=digit[3];;//  3 
    return;   
}
///////////////////////////////////////////////////////
void DisplayMVER(void)
{
    LCDMEM[6]=digit[20];//     //  V
    LCDMEM[7]=digit[21];//  
    LCDMEM[8]=digit[2];//  2
    LCDMEM[9]=digit[7];//  2 
    return;   
}
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
//��������DisplayNOver
//��  �ã�����ʾ����ʾOVER
//------------------------------------------------------------------------------
void DisplayNOver()
{ 
    LCDMEM[2]=digit[18];//  o
    LCDMEM[1]=digit[20];//  v
    LCDMEM[0]=digit[19];//  r
    return;
}
//------------------------------------------------------------------------------
//��������DisplayNUnder
//��  �ã�����ʾ����ʾUNDER
//------------------------------------------------------------------------------
void DisplayNUnder()
{ 
    LCDMEM[2]=digit[20];//  o
    LCDMEM[1]=digit[13];//  v
    LCDMEM[0]=digit[19];//  r  
    return;   
}
//-----------------------------------------------------------------------------
//----------------------------------------------------------------------------------
void DisplayMea()
{
   
    int x=0,y=0,z=0,i=0;  
 
    i=a1  ;
    z=a2  ;
    y=a3  ;
    x=a4  ; 
    if(measing==0 || measing==4|| measing==3)
    {
    if(sys_mode==MODE_AUTO_pH ||sys_mode==MODE_pH ||sys_mode==MODE_CAL)
    {
      if(v<1000)
      {
        LCDMEM[6]=0;
        if(v<100)
          LCDMEM[7]=digit[0];
        else
        {
          LCDMEM[7]=digit[z];
          //LCDMEM[7]=digit[y];
        } 
         if(v<10)
          LCDMEM[8]=digit[0];
        else LCDMEM[8]=digit[y];
        LCDMEM[9]=digit[x];
      }
      else
      {
        LCDMEM[6]=digit[1];
        LCDMEM[7]=digit[z];
        LCDMEM[8]=digit[y];
        LCDMEM[9]=digit[x];
      }
        
    }
    else
    {
      
        if(v<1000)
       {
         LCDMEM[6]=0;
         if(v<100)
           LCDMEM[7]=0;
         else 
         {
           LCDMEM[7]=digit[z];
          // LCDMEM[7]=digit[z];
         } 
          if(v<10)
           LCDMEM[8]=0;
         else LCDMEM[8]=digit[y]; 
         LCDMEM[9]=digit[x]; 
       }
      else 
      {
        LCDMEM[6]=digit[i];
        LCDMEM[7]=digit[z]; 
        LCDMEM[8]=digit[y];
        LCDMEM[9]=digit[x];
      }
      }
    }
    else
    {
   if(mode_save==0 || mode_save==2 )
      {
       // if(mode==0 || mode==2)
       // {
          if(v<1000)
          {
            LCDMEM[6]=0;
            if(v<100)
              LCDMEM[7]=digit[0];
            else
            {
              LCDMEM[7]=digit[z];
              //LCDMEM[7]=digit[y];
            } 
             if(v<10)
              LCDMEM[8]=digit[0];
            else LCDMEM[8]=digit[y];
            LCDMEM[9]=digit[x];
          }
          else
          {
            LCDMEM[6]=digit[1];
            LCDMEM[7]=digit[z];
            LCDMEM[8]=digit[y];
            LCDMEM[9]=digit[x];
          }        
       }
      
      else 
      {
       if(v<1000)
       {
         LCDMEM[6]=0;
         if(v<100)
           LCDMEM[7]=0;
         else 
         {
           LCDMEM[7]=digit[z];
          // LCDMEM[7]=digit[z];
         } 
          if(v<10)
           LCDMEM[8]=0;
         else LCDMEM[8]=digit[y]; 
         LCDMEM[9]=digit[x]; 
       }
      else 
      {
        LCDMEM[6]=digit[i];
        LCDMEM[7]=digit[z]; 
        LCDMEM[8]=digit[y];
        LCDMEM[9]=digit[x];
      
      }
      }
    }
    return;
    //x++;
}
/////////////////////////////////////////////////////////////////////////////////
void DisplayTemp()
{
   
    int j=0,k=0,l=0;  
    if(key_set==1)
    { 
      LCDMEM[1]=digit[0];
      LCDMEM[0]=digit[set_i];
    }
    else
    {         
      j=a5 ;
      k=a6 ;
      l=a7 ;
      if(temp2<100)
        LCDMEM[2]=0;  
      else LCDMEM[2]=digit[j]; 
      LCDMEM[1]=digit[k];    
      LCDMEM[0]=digit[l]; 
    
    }
    return;
}/*
//////////////////////////////////////////////////////////////////////////////////////
void temp_display(void)
{
  if(RANGE_TEMP==0)
  {
    DisplayTemp();
    if(temp2>=1000&& temp2<=1200)
      BSET(SEG_7BC); 
    else BCLR(SEG_7BC);  
    BSET(SEG_P4  );
    BSET(SEG_C  );
    if(sign_t==1)
      BSET(SEG_BAR2); 
    else ;
  }
  else if(RANGE_TEMP==1)
    DisplayTempMUndr();
  else DisplayTempMOver();
  return;
}
*/
///////////////////////////////////////////////////////////////////////////
void DisplaySave()
{ 
  int k=0,l=0; 
  if(measing==1 ||measing==2)
  { 
    k=(sumd4%100/10)  ;
    l=(sumd4%10)  ;
    LCDMEM[3]=digit[l];
    LCDMEM[4]=digit[k];
   
  }
  else 
  {   
    k=((sumd-1)%100/10)  ;
    l=((sumd-1)%10)  ;
    LCDMEM[3]=digit[l];
    LCDMEM[4]=digit[k]; 
   
    
  }
  
    return;
}
/*
void DisplayMea()
{
    int x=0,y=0,z=0,i=0,j=0,k=0,l=0,m=0,n=0; 
    x=(v/10000)  ;
    y=(v%10000/1000)  ;
    z=(v%1000/100) ;
    i=(v%100/10)  ;
    j=(temp%)  ;
      
      
    LCDMEM[3]=digit[x];    
    LCDMEM[4]=digit[y];    
    LCDMEM[5]=digit[z];
    LCDMEM[6]=digit[i];
    LCDMEM[7]=digit[j]; 
}*/
//==============================================================================
//��������DisplayMODE
//��  �ã�����ģʽ��ʾ����
//==============================================================================
//------------------------------------------------------------------------------
//��������ģʽ����ʾ����
//------------------------------------------------------------------------------
void DisplayCal()
{
 
   
   DisplayMea();
   DisplayTemp();
   BSET(SEG_AUTO );
   BSET(SEG_pH  ); 
   BSET(SEG_P2  );
   BSET(SEG_P4  );
   BSET(SEG_C  ); 
   BSET(SEG_ATC ); 
   return;
}
//==============================================================================
void DisplayOff()
{
  
  power=1;  
  WDTCTL =WDTPW +WDTCNTCL+ WDTHOLD;
  IE1 &= ~ WDTIE;
  
  
  Delay(); 
 
 
  P2DIR = 0X00; 
  P2OUT = 0X00; 
  P1DIR &= 0X02;                             //�������ŷ������� p1.0~p1.7
  P1IES |= 0x02;                             //�½����ж�     
  P1IE |= 0X02;
  P1IFG = 0; 
  SD16CTL   = 0;
  SD16CCTL0 = 0;             // Single conv, group with CH1
  SD16CCTL1 = 0;             // Single conv, group with CH2
  SD16CCTL2 = 0;     
  LCDCTL = 0; 
  BTCTL =0 ; 
  _LCDCLR;
  _EINT();
  LPM3;  
  power=0;
  return;
}
//==============================================================================
void Wait_flash(void)
{
  char i;
  if(sumd2==0)
    i=0;
  else if(sumd2>=10)
    i=20;
  else i=2;
 /*if(sumd2==0)
    {
      ;
    }  
 else if(sumd2>=10)
    {
      if(lcd_k>=i/2)
        lcd_i=0;
      else lcd_i=1;
      if(lcd_k==i)
        lcd_k=0;
      else lcd_k++;
    }*/
    if(sumd2==0)
      ;
   else
    {
      if(lcd_k>=i/2)
        lcd_i=0;
      else lcd_i=1;
      if(lcd_k==i)
        lcd_k=0;
      else
      {
       if(lcd_k>i)
         lcd_k=0;
       else lcd_k++;
      }
    }
  
  if(cal==0) 
    ; 
  else BSET(SEG_CAL);  
  if(lcd_i==0)
  { 
    if(lobat==1)
      BSET(SEG_BAT);
    else ;
    if(sys_mode==MODE_AUTO_pH || sys_mode==MODE_pH  )
    {
      if(hold==0)
      { 
        if(sys_mode==MODE_AUTO_pH)
      {
        BSET(SEG_WAIT);
      }
        else ;
      }
      else
      {
        if(cal_ok==1)//if(point==2 ||point==3 )          ////�޸�
        {
          if(error==0)
            BSET(SEG_HOLD);
          else ;
        }
        else  ;//BSET(SEG_CAL);;
      }
      if(point==0)
      {
         if(buff==0)
      {
        if(mv<=1000 && mv>=-1000)
         BSET(SEG_700);//ph1=pH_700[tt];  
        else if(mv>1000)
           BSET(SEG_401);//ph1=pH_401[tt];
        else  BSET(SEG_1001);//ph1=pH_1001[tt];
      }
      else
      {
       if(mv<=1000 && mv>=-817)
         BSET(SEG_686);//ph1=pH_686[tt];  
        else if(mv>1000)
           BSET(SEG_400);//ph1=pH_400[tt];
        else  BSET(SEG_918);//ph1=pH_918[tt];
       // ph1=pH_686[tt]; 
      }
        /*
        if(buff==0)
          BSET(SEG_700);
        else BSET(SEG_686);*/
      }
      else if(point==1)
      {
        if(measing==4)
        {  
          if(buff==0)
          {
            if(mv<=900 && mv>=-900)
             BSET(SEG_700);//ph1=pH_700[tt];  
            else if(mv>900)
               BSET(SEG_401);//ph1=pH_401[tt];
            else  BSET(SEG_1001);//ph1=pH_1001[tt];
          }
          else
          {
           if(mv<=983 && mv>=-817)
             BSET(SEG_686);//ph1=pH_686[tt];  
            else if(mv>983)
               BSET(SEG_400);//ph1=pH_400[tt];
            else  BSET(SEG_918);//ph1=pH_918[tt];
           // ph1=pH_686[tt]; 
      /*     if(buff==0)
          BSET(SEG_700);
        else BSET(SEG_686);*/
        }
        }
        else
        {
           if(buff==0)
          {
            if(v1<=900 && v1>=-900)
             BSET(SEG_700);//ph1=pH_700[tt];  
            else if(v1>900)
               BSET(SEG_401);//ph1=pH_401[tt];
            else  BSET(SEG_1001);//ph1=pH_1001[tt];
          }
          else
          {
           if(v1<=983 && v1>=-817)
             BSET(SEG_686);//ph1=pH_686[tt];  
            else if(v1>983)
               BSET(SEG_400);//ph1=pH_400[tt];
            else  BSET(SEG_918);//ph1=pH_918[tt];
           // ph1=pH_686[tt]; 
      /*     if(buff==0)
          BSET(SEG_700);
        else BSET(SEG_686);*/
        }
          /*
        if(buff==0)
          BSET(SEG_700);
        else BSET(SEG_686);*/
        if(cal==0) 
          ;//BSET(SEG_F);
        else
        {
          if(buff==0)
          {
          BSET(SEG_401);BSET(SEG_1001);
          }
          else
          {
            BSET(SEG_400);BSET(SEG_918);
          }
        }
        }
      }
      else if(point==2)                 //�޸�
      {
        
        if(buff==0)
        { 
          
          BSET(SEG_700);
          if(measing==4)
          {
         if(v2>0)
        BSET(SEG_401);
        else BSET(SEG_1001);
          }
          else
          {if(v_cal>0)
        BSET(SEG_401);
        else BSET(SEG_1001);// BSET(SEG_1001);
          }
        if(cal==2) 
        {if(v_cal<0)
        BSET(SEG_401);
        else BSET(SEG_1001);// BSET(SEG_1001);
        }
        else ;
        }
        else
        {
          BSET(SEG_686);
          if(measing==4)
          {
          if(v2>0)
        BSET(SEG_400);
        else BSET(SEG_918);
          }
          else
          {
            if(v_cal>0)
        BSET(SEG_400);
        else BSET(SEG_918);// BSET(SEG_1001);
          }
        if(cal==2) 
        {
              if(v_cal<0)
        BSET(SEG_400);
        else BSET(SEG_918);//BSET(SEG_918);
        }
        else ;
        }
      }
      else                      //����
      {if(buff==0)
      {
        BSET(SEG_700);
        BSET(SEG_401);
        BSET(SEG_1001);
      }
      else
      {  BSET(SEG_686);
        BSET(SEG_400);
        BSET(SEG_918);
      }
      }
    }
    if(sys_mode==MODE_AUTO_mV )
    {
      if(hold==0)
        BSET(SEG_WAIT);
      else BSET(SEG_HOLD);
    }
   
      lcd_i=1;
  /* if(lcd_i>=i)
      lcd_i=0;
    else lcd_i++;*/
  }
  else 
  {
    if(measing==4)
    {
      if(sys_mode==MODE_AUTO_pH || sys_mode==MODE_pH)
      {
        if(point==1)
        { if(buff==0)
          {
            if(mv<=900 && mv>=-900)
             BSET(SEG_700);//ph1=pH_700[tt];  
            else if(mv>900)
               BSET(SEG_401);//ph1=pH_401[tt];
            else  BSET(SEG_1001);//ph1=pH_1001[tt];
          }
          else
          {
           if(mv<=983 && mv>=-817)
             BSET(SEG_686);//ph1=pH_686[tt];  
            else if(mv>983)
               BSET(SEG_400);//ph1=pH_400[tt];
            else  BSET(SEG_918);//ph1=pH_918[tt];
          /*
          
          if(buff==0)
            BSET(SEG_700);
          else BSET(SEG_686);*/
          }
        }
        else if(point==2)                 //�޸�
      {
        if(buff==0)
        {
        BSET(SEG_700);  
        if(v2>0)
        BSET(SEG_401);
        else BSET(SEG_1001);
       // BSET(SEG_401);
        }
        else
        {
          BSET(SEG_686);  
        if(v2>0)
        BSET(SEG_400);
        else BSET(SEG_918);
          
        //  BSET(SEG_400);
        }
      }
      else                      //����
      {
        if(buff==0)
      {
        BSET(SEG_700);
        BSET(SEG_401);
        BSET(SEG_1001);
      }
      else
      {
        BSET(SEG_686);
        BSET(SEG_400);
        BSET(SEG_918);
      }
      }
      }
    }
    else
    {
    if(sys_mode==MODE_AUTO_pH || sys_mode==MODE_pH )
    {
      if(point==0)
        ;//BSET(SEG_STAND);
      else if(point==1)
      { if(buff==0)
          {
            if(v1<=900 && v1>=-900)
             BSET(SEG_700);//ph1=pH_700[tt];  
            else if(v1>900)
               BSET(SEG_401);//ph1=pH_401[tt];
            else  BSET(SEG_1001);//ph1=pH_1001[tt];
          }
          else
          {
           if(v1<=983 && v1>=-817)
             BSET(SEG_686);//ph1=pH_686[tt];  
            else if(v1>983)
               BSET(SEG_400);//ph1=pH_400[tt];
            else  BSET(SEG_918);//ph1=pH_918[tt];
           // ph1=pH_686[tt]; 
      /*     if(buff==0)
          BSET(SEG_700);
        else BSET(SEG_686);*/
        }/*
       if(buff==0)
         BSET(SEG_700);
       else  BSET(SEG_686);*/
       // BSET(SEG_SLOPE);
      }
      else if(point==2)                 //�޸�
      {
          if(buff==0)
      {
        BSET(SEG_700);
        if(v_cal>0)
        BSET(SEG_401);
        else BSET(SEG_1001);
      //  BSET(SEG_401);BSET(SEG_1001);
      }
      else
      {
        BSET(SEG_686);
         if(v_cal>0)
        BSET(SEG_400);
        else BSET(SEG_918);//BSET(SEG_400);BSET(SEG_918);
      }
      }
      else                      //����
      {
        if(cal_ok==1)
        {
            if(buff==0)
            {
              BSET(SEG_700);
              BSET(SEG_401);
              BSET(SEG_1001);
            }
            else
            {
              BSET(SEG_686);
              BSET(SEG_400);
              BSET(SEG_918);
            }    
          
         
        }
        else
        {
           if(buff==0)
      {
        BSET(SEG_700);
        BSET(SEG_401);
      //  BSET(SEG_1001);
      }
      else
      {
        BSET(SEG_686);
        BSET(SEG_400);
       // BSET(SEG_918);
      }
        }
      }
      
    }
    if(hold==0 )
      ;// BSET(SEG_WAIT);
    else
    {
      if(sys_mode==MODE_AUTO_pH)
      {
          if(cal_ok==1)//if(point==2 ||point==3 )          ////�޸�
          BSET(SEG_HOLD);
        else ;
      }
      else  BSET(SEG_HOLD);
    }
    }lcd_i=0;
  /* if(sumd2>=10)
      lcd_i++;
    else lcd_i=0;*/
  }
}
///////////////////////////////////////////////////////////////////////////////
void Wait_flash1(void)
{
   if(lcd_i==0)
   {
     if(lobat==1)
      BSET(SEG_BAT);
    else ;
    lcd_i=1;
   }
   else lcd_i=0;
    if(mode_save ==MODE_AUTO_pH ||mode_save ==MODE_pH )
    {      
     if(point==1)
      {
       if(buff==0) BSET(SEG_700);
       else  BSET(SEG_686);
       // BSET(SEG_SLOPE);
      }
      else if(point==2)                 //�޸�
      {
          if(buff==0)
      {
        BSET(SEG_700);
        if(v_cal>0)
        BSET(SEG_401);
        else BSET(SEG_1001);
      //  BSET(SEG_401);BSET(SEG_1001);
      }
      else
      {
        BSET(SEG_686);
         if(v_cal>0)
        BSET(SEG_400);
        else BSET(SEG_918);//BSET(SEG_400);BSET(SEG_918);
      }
      }
      else                      //����
      { 
        if(measing==1 || measing==2)
        {
          if(point==0)
            ;
          else
          {
              if(buff==0)
        {
        BSET(SEG_700);
        BSET(SEG_401);
        BSET(SEG_1001);
        }
        else
        {BSET(SEG_686);BSET(SEG_400);BSET(SEG_918);
        }
          }
        }
        else
        {
        if(buff==0)
        {
        BSET(SEG_700);
        BSET(SEG_401);
        BSET(SEG_1001);
        }
        else
        {BSET(SEG_686);BSET(SEG_400);BSET(SEG_918);
        }
        }
   /*   if(point==0)
       ;// BSET(SEG_STAND);
      else if(point==1)       
        BSET(SEG_700);
      else
      {
        BSET(SEG_700);
        BSET(SEG_401);*/
      }
    }
    else ;
  
   
 
}
////////////////////////////////////////////////////////////////////////////////
void Each_flash(void)
{  
  if(lcd_j== 0)
  {
    if(lobat==1)
      BSET(SEG_BAT);
    else ;
    if(delte==1)
    {
      if(each==0)
        BSET(SEG_Each);
      else BSET(SEG_All);
      lcd_j=1;   
    }
    else if(delte==2)    
    {
      if(each==0)
      {
        BSET(SEG_Each);
       // DisplaySave();
      }
      else ;//BSET(SEG_All);
      lcd_j=1;  
    }
  }
  else 
  {
    lcd_j=0;
    if(delte==2)    
    {
      if(each==0)
        BSET(SEG_Each);
      else ;
    }
    else ;
  }
}
////////////////////////////////////////////////////////////////////////////////
void DisplayMesaM(void)
{
 
  if(error==1)
    DisplayMERR1();
  else if(error==2)
    DisplayMERR2();
  else if(error==3)
    DisplayMERR3();
  else
  {
  if(RANGE==0)
    DisplayMea();
  else if(RANGE==1)
    DisplayMOver();
  else DisplayMUndr();
  }
  if(RANGE_TEMP==0)
    DisplayTemp();
  else if(RANGE_TEMP==2)
    DisplayTempMOver();
  else DisplayTempMUndr();
  if(sys_mode==MODE_AUTO_pH )
  {
    BSET(SEG_AUTO );
    if(RANGE==0)
    {
      if(error==0)
        BSET(SEG_P2  );
      else ;
    }
    else ;
    BSET(SEG_pH  ); 
  }
  else if(sys_mode==MODE_AUTO_mV)
  {
     BSET(SEG_AUTO );
     BSET(SEG_mV  );
  }
  else if(sys_mode==MODE_pH)
  {
    BSET(SEG_pH  );
   if(RANGE==0)
    {
      if(error==0)
        BSET(SEG_P2  );
      else ;
    }
    else ;
    hold=0;
  }
  else 
  {
     BSET(SEG_mV  );
     hold=0;
  }  
  if(RANGE_TEMP==0)
  {
  BSET(SEG_P4  );
  BSET(SEG_C  ); 
  }
  else ;
  if(atc==0 || atc==2 || atc==3)
    BSET(SEG_ATC );  
  else BSET(SEG_MAN );
  if(RANGE_TEMP==0)
  {
    if(temp2>=1000)
       BSET(SEG_7BC ); 
    else ;
  }
  else ; 
  if(RANGE==0)
  {
    if(sys_mode==MODE_AUTO_mV || sys_mode==MODE_mV)
    {
      if(mv<0)
        BSET(SEG_BAR1);
      else ;
    }
    else if(sys_mode==MODE_AUTO_pH ||sys_mode==MODE_pH)
    {
      if(ph<0)
      BSET(SEG_BAR1);
      else ;
    }
  }
  else ;
  if(RANGE_TEMP==0)
  {
    if(temp1<0)
    BSET(SEG_BAR2);
  else ;
  }
}
///////////////////////////////////////////////////////////////////////////////////////////
void DisplayMesaR(void)
{
 
  
  if(RANGE==0)
    DisplayMea();
  else if(RANGE==1)
    DisplayMOver();
  else DisplayMUndr();
  if(RANGE_TEMP==0)
    DisplayTemp();
  else if(RANGE_TEMP==2)
    DisplayTempMOver();
  else DisplayTempMUndr();
  if(mode_save ==MODE_AUTO_pH )
  {
    BSET(SEG_AUTO );
    if(RANGE==0)
      BSET(SEG_P2  );
    else ;
    BSET(SEG_pH  ); 
  }
  else if(mode_save==MODE_AUTO_mV)
  {
     BSET(SEG_AUTO );
     BSET(SEG_mV  );
  }
  else if(mode_save==MODE_pH)
  {
    BSET(SEG_pH  );
    if(RANGE==0)
      BSET(SEG_P2  );
    else ;
    hold=0;
  }
  else 
  {
     BSET(SEG_mV  );
     hold=0;
  }  
  if(RANGE_TEMP==0)
  {
  BSET(SEG_P4  );
  BSET(SEG_C  ); 
  }
  else ;
  if(atc==0)
    BSET(SEG_ATC );  
  else BSET(SEG_MAN );
  if(RANGE_TEMP==0)
  {
    if(temp2>=1000)
       BSET(SEG_7BC ); 
    else ;
  }
  else ;
  if(RANGE==0)
  {
    if(mode_save==MODE_AUTO_mV || mode_save==MODE_mV)
    {
      if(mv<0)
        BSET(SEG_BAR1);
      else ;
    }
    else if(mode_save==MODE_AUTO_pH ||mode_save==MODE_pH)
    {
      if(ph<0)
      BSET(SEG_BAR1);
      else ;
    }
  }
  else ;
  if(RANGE_TEMP==0)
  {
    if(temp1<0)
    BSET(SEG_BAR2);
  else ;
  }
}
////////////////////////////////////////////////////////////////////////////////////////////////
void DisplayD(void)
{ 
  char i,k,*flash_ptr2,*flash_ptr3,*flash_ptr4; 
  int j,*flash_ptr,*flash_ptr1; 
  flash_ptr = 0; 
  flash_ptr1 = 0;
  flash_ptr = (int*)0xfa00;
  flash_ptr1 = (int*)0xfb00;
  flash_ptr2 = (char*)0xfc00;
  flash_ptr3 = (char*)0xfc64;
  flash_ptr4 = (char*)0xfcff;//0xfcc8;
  sumd = (char)*flash_ptr4++;
  if(sumd4==0)
    sumd4=sumd; 
  else ; 
  for(i=0;i<=sumd4;i++)
  {
    if(i==sumd4)
    {
     k=(char)*flash_ptr2++;
     atc=(char)*flash_ptr3++;
     buff=(char)*flash_ptr3++;;
     point=(char)*flash_ptr3++;;
     mode_save=k;
    }
    else 
    {
      
      flash_ptr2++;
      flash_ptr3++;flash_ptr3++;flash_ptr3++;
      if(sumd4>=255)
        sumd4=0;
      else ;
    }
  } 
  for(j=0;j<=sumd4;j++)
  {
    if(j==sumd4)
    { 
      if(mode_save==MODE_pH || mode_save==MODE_AUTO_pH  )
        ph=(int)*flash_ptr++;
      else mv=(int)*flash_ptr++;      
      temp1=(int)*flash_ptr1++;
    }
    else 
    {
      flash_ptr++;
      flash_ptr1++;
        
    }
  } 
 
  if(mode_save ==MODE_AUTO_pH  || mode_save ==MODE_pH )
  {
    if(ph>=0)
      v=ph;
    else
    {
      v=ph*(-1); 
    }
  }
  else
  {
    if(mv>=0)
      v=mv;
    else v=mv*(-1);
  }   
  if(mode_save ==MODE_AUTO_pH  ||mode_save ==MODE_pH )
  {
    if(ph>=-200 && ph<=1600)
      RANGE=0;
    else if(ph>1600)
      RANGE=1;
    else RANGE=2;
  }
  else 
  {
    if(mv<=1999 && mv>=-1999)
      RANGE=0;
    else if(mv>1999)
      RANGE=1;
    else RANGE=2;
  }
  if(temp1>=0)
    temp2=temp1;
  else temp2=temp1*(-1);  
 
}
////////////////////////////////////////////////////////////////////////////////////////////
/*
void DisplayRecall()
{
   if(mode==MODE_AUTO_pH)
   {
     BSET(SEG_AUTO );
      if(RANGE==0)
      {
        BSET(SEG_pH  );//BSET(SEG_P2  );
        if(recal==0 )
         ;
       else 
       {
         if(point==1) 
         {
           BSET(SEG_STAND);
           // BSET(SEG_SLOPE);
         }
         else if(point==2)      
         {
           BSET(SEG_STAND);
           BSET(SEG_SLOPE);
         }
         else ;
       }
        if(delte==0)
         ;
       else 
       {
         if(point==1) 
         {
           BSET(SEG_STAND);
           // BSET(SEG_SLOPE);
         }
         else if(point==2)      
         {
           BSET(SEG_STAND);
           BSET(SEG_SLOPE);
         }
         else ;
       }
      }
     else ;//BSET(SEG_pH  );  
    
   }
   if(mode==MODE_AUTO_mV)
   {
     BSET(SEG_AUTO );
      if(RANGE==0)
       BSET(SEG_mV  );//BSET(SEG_pH  );/BSET(SEG_P2  );
     else ;
   }
   if(mode==MODE_pH)  
   {
     if(RANGE==0)
     {
       BSET(SEG_pH  );//BSET(SEG_P2  );
       if(recal==0 )
         ;
       else 
       {
         if(point==1) 
         {
           BSET(SEG_STAND);
           // BSET(SEG_SLOPE);
         }
         else if(point==2)      
         {
           BSET(SEG_STAND);
           BSET(SEG_SLOPE);
         }
         else ;
       }
         if(delte==0)
         ;
       else 
       {
         if(point==1) 
         {
           BSET(SEG_STAND);
           // BSET(SEG_SLOPE);
         }
         else if(point==2)      
         {
           BSET(SEG_STAND);
           BSET(SEG_SLOPE);
         }
         else ;
       }
     }
     else ;
     
   }
   if(mode==MODE_mV)
   { 
     if(RANGE==0)
       BSET(SEG_mV  );//BSET(SEG_pH  );/BSET(SEG_P2  );
     else ;
   }   
   if(mode==MODE_pH || mode==MODE_AUTO_pH  )
   {
     if(RANGE==0)
       BSET(SEG_P2  );
     else ;
   }
   else ; 
   if(atc==1)
     BSET(SEG_MAN );
   else BSET(SEG_ATC ); 
   if(mv>=0)
     ;
   else 
   {
     if(RANGE==0)
       BSET(SEG_BAR1);
     else ;
   }
   return;
 
}

*/

//==============================================================================

//==============================================================================
//��������Display
//��  �ã����ݵ�ǰģʽ���ø�����ʾ����
//==============================================================================
/*void Display(void)
{  
  switch(sys_mode)               //����ģʽ�ж���ʾ����   
  {
   case 0 : DisplayMea(); break;        
   case 1 : DisplayCal(); break;
   case 2 : DisplayCLR(); break;
   case 3 : DisplayOut(); break;
   case 4 : DisplayOff(); break;
   case 5 : DisplaySave(); break;
   case 6 : DisplayRecall(); break;
  }
}*/

