/*******************************************************************************
FLASH����
FLASH�Ķ�д ���������������
*******************************************************************************/
void SaveDataA(void)                                                            //д����Ҫ���������
{
  char i;                           
  float *flash_ptr;
  flash_ptr = (float *)0x1000;                                                  //д��A��
  FCTL1 = FWKEY +ERASE;                                                         //����FLASH��    
  FCTL3 = FWKEY;
  *flash_ptr = 0;                                                               //��������
  FCTL1 = FWKEY +WRT;
  
 
  *flash_ptr++ = con_ref_v;                                                     //д������
  *flash_ptr++ = tem_ref_v;
  *flash_ptr++ = tem_k;
  *flash_ptr++ = tem_b;
  
  for(i=1;i<SET_POINT;i++)
  {
  *flash_ptr++ = con_k[i];
  *flash_ptr++ = con_b[i];
  }
  
  for(i=0;i<SET_POINT;i++)
  {
   *flash_ptr++ = con_f[i];
  }

  FCTL1 = FWKEY;
  FCTL3 = FWKEY +LOCK;
}

void SaveDataB(void)
{                        
  float *flash_ptr;
  flash_ptr = (float *)0x1000;                                                  //д��B��
  FCTL1 = FWKEY +ERASE;
  FCTL3 = FWKEY;
  *flash_ptr = 0;
  FCTL1 = FWKEY +WRT;
         
  *flash_ptr++ = std_kh;   
  *flash_ptr++ = std_kl; 
  *flash_ptr++ = std_hok;
  *flash_ptr++ = std_lok;
  
  
  FCTL1 = FWKEY;
  FCTL3 = FWKEY +LOCK;
}
/////////////////////////////////////////////////////////////////////////////
void ReadData(void)                                                             //���������������
{
   char i;
   float *flash_ptr;
   flash_ptr = (float *)0x1080;
    

   con_ref_v = *flash_ptr++;
   tem_ref_v = *flash_ptr++;     
   tem_k = *flash_ptr++;
   tem_b = *flash_ptr++;
   
  for(i=1;i<SET_POINT;i++)
  {
    con_k[i] = *flash_ptr++;
    con_b[i] = *flash_ptr++;
  }
  
   for(i=0;i<SET_POINT;i++)
  {
    con_f[i] = *flash_ptr++ ; 
  }
 //  ��ȡУ��ϵ��---------------------------------------------------------------------------------
   flash_ptr = (float *)0x1000;
  
   std_kh = *flash_ptr++;
   std_kl = *flash_ptr++;
   std_hok = *flash_ptr++;
   std_lok = *flash_ptr++;
  
   
   
 //  if((std_k>1.5)||(std_k<0.5)) std_k = 1;     //flash��������˷Ƿ����� �򸶳�ֵ1��

}