//2019 12 11  �޸�û�д洢ʱ��Recall��洢��02��ʼ��bug
//2020 04 26  �޸�3��У׼��slope��offest��ʾ��
//2020 6  24 V2.2�޸�bug
#include <msp430x42x.h>
#include "Econsense sys.h"
#include "key.c"
#include "lcd.c"
#include "adc.c"
#include "ph110_sys1.c"
#include "count.c"
#include "cal.c"

signed int x11=0,xl2=0,xl3=0;;
//////////////////////////////////////////////////////////////////////////////
void Measure(void)
{ //Adc();
  if(hold==1)
  {//Lobat(); 
    if(sys_mode==MODE_AUTO_pH )//|| sys_mode==MODE_pH)
    {
      if(point<1)
      {
        //  Adc();                                    //ADת������
          Count();  
     /*   if(temp1<0 || temp1>600)
          {
          error=3;
        }
        else 
          {*/
            error=0;
        v1=mv;
        Revise_temp();
        Revise();// Slope();
     
          v=(int)(ph1*100);
          ph=v;
     //   }
      }
      else
      {
       
        // Adc();
         
         if(cal==2)
           Temp();
         else ;
      if(error==0)
        ;
      else Count();   
      }
    }
    else ;//Lobat();
    ;
  }
  else
  {
      //  Adc();  Adc();                               //ADת������
    Count();           //�������
    if(measing==4)
    {   
      
      if(sys_mode==MODE_AUTO_pH )//|| sys_mode==MODE_pH)
      { 
        if(point==0 || point==1)
         {
          
          v1=mv;t2=temp1/10+273.15;
          Revise_temp();
          Revise();// Slope();
         
            v=(int)(ph1*100);
          }    
        else if(point==2)
         {
          v2=mv;t2=temp1/10+273.15;
          Revise_temp();
          Revise(); 
          if(error==0)
            Slope();
       
           //v2=mv;
           v=(int)(ph2*100);   
         }
         else// if(point==3) 
         {
          v3=mv;t2=temp1/10+273.15;
          Revise_temp();
          Revise(); 
          if(error==0)
            Slope();
       
           //v2=mv;
           v=(int)(ph2*100);   
         }
      }
      else ;
    }
    else 
    { 
      if(sys_mode==MODE_AUTO_pH )//|| sys_mode==MODE_pH)
      {
        if(point==0)
        {
        /*  if(temp1<0 || temp1>600)
          {
          error=3;
          }
          else 
            {*/
          error=0;
          v1=mv;
          Revise_temp();
          Revise();// Slope();
       
            v=(int)(ph1*100);
            ph=v;
         // }
        }
      else ;
    }
    else ; 
    if(point==0)
      ;
    else
    {
      if(error!=0)
      {
        
        error=0;
      }
      else ;
    }   
    }
 //   }
       
  } 
  cound_mv(); 
  _LCDCLR;
  DisplayMesaM();
  Wait_flash();
}
//////////////////////////////////////////////////////////////////////////////
void Save(void)
{
  //mode=measing;
  if(sumd==255)
    sumd=1;
  else ;
  if(sumd>=51)
  {
    BSET(SEG_Full );
    measing=0;
  }
  else
  {
    Savedata();     
    _LCDCLR;
    BSET(SEG_Save ); 
    DisplaySave();      
    DisplayMesaM();
    Wait_flash();
    measing=0;
   // Delay();
  }
}
//////////////////////////////////////////////////////////////////////////////
void Cal(void)
{ 
  
  if(sys_mode ==MODE_pH)
  {
    if(error==0)
      hold=1;
    else{
      hold=0;Measure();}
  }
  else Measure(); 
  Cal1();
  return;
}
//////////////////////////////////////////////////////////////////////////////
void Recall(void)
{ 
 
  if(recal==0)
  {
     _LCDCLR;
    DisplayRCL();
    BSET(SEG_Recall);
  }
  else if(recal==1)
  {
  DisplayD();
  tempR();
  cound_mv();
  _LCDCLR;
  BSET(SEG_Recall);
  DisplaySave();
  DisplayMesaR();  
  Wait_flash1(); //Wait_flash1();
  }
  else 
  {
    _LCDCLR;
    DisplayNO();
    BSET(SEG_Recall);sumd=0;
  }
  return;
}
//////////////////////////////////////////////////////////////////////////////
void Delete(void)
{  /*
  char i,k,*flash_ptr2,*flash_ptr3,*flash_ptr4; 
  int j,*flash_ptr,*flash_ptr1; 
  flash_ptr = 0; 
  flash_ptr1 = 0;*/
  if(delte==0)
  {
     _LCDCLR;
    DisplayDEL();
    BSET(SEG_Delete);
  }
  else if(delte==1)
  {
    _LCDCLR;
    DisplayDEL();
    BSET(SEG_Delete);
    Each_flash();
  }
  else if(delte==2)
  {
    if(each==1)
    {
      _LCDCLR;
      DisplayNO();
      if(sumd==0)
        ;
      else delteall();
      sumd=0;
    }
    else
    {
      if(sumd4==0xff)
        sumd4=0;
      else ;
      DisplayD();
    if(sumd==0xff || sumd==0)
    {
       _LCDCLR;
      DisplayNO();
      sumd=0;
      sumd4=1;
    }
    else
    {
      tempR();
      cound_mv();
     _LCDCLR;
     if(lcd_j== 0)
       DisplaySave();
     else ;
     DisplayMesaR();  
     Each_flash();
    }
    }
  }
  else if(delte==3)
  {
    if(sumd==0xff)
      ;
    else 
    {
    Savedatb();
    delte=2;
    sumd4=sumd-1;
    if(sumd==1)
      sumd=0;
    else ;
    }
  }
  else 
  {
    _LCDCLR;
    DisplayNO();
  }
 
   BSET(SEG_Delete);
   return;
}
//////////////////////////////////////////////////////////////////////////////
void Set(void)
{ 
  float x1,x2,x3,x4,vt1,vt2,vt3,vt4;
  if(ai==0)
  {
    _LCDCLR;
    DisplayMVER();BSET(SEG_P3  );ai=1;Delay2();
  }
  else
  {
//  Adc();                                    //ADת������
  //Count();                                  //�������   
  //Adc();                                    //ADת������
  Count();                                  //�������  
  if(set_i>2)
    v=results[1];   
  else v=results[0];    
 if(mode==MODE_SET)
 {
      if(set_i==1)
      {
        mv0=results[0];  
      }
      else if(set_i==2)
      {
        mv1000=results[0];  
      }
      else if(set_i==3)
      {
        mv2000=results[0];  
      }
      else if(set_i==4)
      {
        r30k=results[1]; 
      }
      else if(set_i==5)
      {
        r10k=results[1];
      }
      else if(set_i==6)  
      {
        r1k=results[1]; 
        set_ok=1;  
        
      }
      else ;
  
    if(set_ok==1)
    {      
      x1=10000.0/(mv1000-mv0);
      x2=-mv0*x1;
      x3=10000.0/(mv0-mv2000);
      x4=-mv0*x3;
      vt4=(r30k-r10k)*30.0/(3.0*r10k-r30k)*1000.0;
      vt3=r10k*(vt4+10000.0)/10000.0; 
      vt2=(r10k-r1k)*10.0/(10000.0/1000.0*r1k-r10k)*1000.0;
      vt1=r1k*(vt2+1000.0)/1000.0; 
      mv_k1=x1;
      mv_b1=x2; 
      mv_k2=x3;
      mv_b2=x4;
      k_r1=vt3;
      b_r1=vt4;
      k_r2=vt1;
      b_r2=vt2;
      Savedata_set();
      temp_man=250;
      ph_offset2 = 0;
      slope2=0 ;
      point=0; 
      buff= 0; 
      sys_mode=0 ;
      sumd=0;    
      key_set=0;
      measing=0;
      Savedata_a(); ai=0;
    }
 }
 else ;
 cound_mv();
 
  _LCDCLR;
  if(mode==MODE_SET)
  {
    key_v=0;
    mode=0;
    DisplayMSave();
    
    
  }
  else
  {
    DisplayMea();
    DisplayTemp();
  }
  }
}
//////////////////////////////////////////////////////////////////////////////
void DisplaySys(void)
 {
   sys();  
   _LCDALL;                //ȫ����
  buzz();                 
  Delay();
  Delay();
  _LCDCLR;
  Delay1();
  if(buff==0)
    v=700; 
  else v=686;
  temp2=250;
  cound_mv();
  DisplayCal(); 
  Delay();
 }

//////////////////////////////////////////////////////////////////////////////
void Off(void)
{
   _DINT();
  _LCDCLR;  
  _LCDMOFF;
  DisplayOff();
  _DINT(); 
  Savedata_a();
  DisplaySys();
  _EINT();
 
  sumd1=0;
  key_v=0;
  P1IFG=0;
  return;

}
//////////////////////////////////////////////////////////////////////////////////////////

void main()
{  
  
aa:
 // data_d[7][50]={1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1};
  DisplaySys();
  if((P2IN & 0x0f)==0X02)
  {
    set_ok=0;ai=0;
    set_i=0;
    key_set=1;
    buzz();
    measing=5;
  }
  else ; 
  if(clear==1)
  {
    clear=0; 
    key_v=0;
    P1IFG=0;
  }
  else ;
  _EINT(); 
  while(1)
  { 
    Adc();
    Lobat(); 
 //   P1IE &= ~ 0Xff;   
    KeyDeal();
    if(measing>6)
      measing=0;
    else ;
    if(clear==1)
     {
      // P1IE &= ~ 0Xff;  
       _DINT();
       mode_save=0;
       mode=0;
       ph_offset2 = 0;
       slope2= 0;
       ph_offset3 = 0;
       slope3= 0;
       temp_man= 250;
       point= 0;
       measing=0 ;
       sys_mode=0;       
       error=0;
       cal=0;
       hold=0; 
       key_v=0;
       P1IFG=0;cal_ok=0;
       v_cal=0;
       v1=0;v2=0;v3=0;
       Savedata_a(); 
       buzz();
       goto aa;
     }
    switch(measing) 
    {      
    case 0   :   Measure();      break; 
    case 1   :   Recall();       break; 
    case 2   :   Delete();       break;
    case 3   :   Save();         break;  
    case 4   :   Cal();          break;     
    case 5   :   Set();          break;
    case 6   :   Off();          break; 
 //   case 7   :   EFF();          break;
    
    } 
   
   
    if(lobat==2)
      Off();
    else ;

    if(P1IN==0X7F)
     {
       if(measing==0)
       {
        if(sys_mode==MODE_AUTO_pH ||sys_mode==MODE_pH)
         {
           if(point>=1)
           {
           if(P1IN==0X7F)  
           {
                   
             xl3++; 
             if(xl3==3)
             {
            if(point==1)
                   {
                     v=(int)slope1; 
                   }
                   else 
                   {
                     v=(int)slope2; 
                   }
             buzz(); 
             sumd7=1;
             }
             else ;
           //  key=0;
             while(xl3>=3)
             {
              if(P1IN==0X7F)   
              {
                if(hold==2)
                 hold=1;
               else ;
             
                 if(xl2==0)
                 {
                   if(point==1)
                   {
                     v=(int)slope1; xl2=1;
                   }
                   else 
                   {
                     v=(int)slope2; 
                    xl2=1;
                   }
                 }
                 else
                 { 
                   if(point==3)
                    {
                     v=(int)slope3; 
                     xl2=0;
                    }
                   else xl2=0;
                 }
               
             cound_mv();
               _LCDCLR;   
               DisplayMea(); 
              DisplayTemp(); 
               BSET(SEG_P3);
               BSET(SEG_EFF);
              BSET(SEG_C  );BSET(SEG_P4  ); 
               BSET(SEG_do  );
              if(atc==1)                
                 BSET(SEG_MAN );
               else BSET(SEG_ATC ); 
             if(point==1)
             {
                if(buff==0)
                {
                  if(v1<=900 && v1>=-900)
                   BSET(SEG_700);//ph1=pH_700[tt];  
                  else if(v1>900)
                     BSET(SEG_401);//ph1=pH_401[tt];
                  else  BSET(SEG_1001);//ph1=pH_1001[tt];
                }
                else
                {
                 if(v1<=983 && v1>=-817)
                   BSET(SEG_686);//ph1=pH_686[tt];  
                  else if(v1>983)
                     BSET(SEG_400);//ph1=pH_400[tt];
                  else  BSET(SEG_918);//ph1=pH_918[tt];
                 // ph1=pH_686[tt]; 
            /*     if(buff==0)
                BSET(SEG_700);
              else BSET(SEG_686);*/
                }
             }
             else if(point==2)
             {
                if(buff==0)
                { 
                  BSET(SEG_700);
                  if(v_cal>0)
                    BSET(SEG_401);
                  else BSET(SEG_1001);
                }
                else
                { 
                  BSET(SEG_686);
                  if(v_cal>0)
                    BSET(SEG_400);
                  else BSET(SEG_918);
                  
                }
             }
             else
             {
               if(xl2==1)
               {
                 if(buff==0)
                { 
                  BSET(SEG_700);
                  if(v_cal>0)
                    BSET(SEG_401);
                  else BSET(SEG_1001);
                }
                else
                { 
                  BSET(SEG_686);
                  if(v_cal>0)
                    BSET(SEG_400);
                  else BSET(SEG_918);
                  
                }
                 
               }
               else
               {
                 if(buff==0)
                  { 
                    BSET(SEG_700);
                    if(v_cal<0)
                      BSET(SEG_401);
                    else BSET(SEG_1001);
                  }
                  else
                  { 
                    BSET(SEG_686);
                    if(v_cal<0)
                      BSET(SEG_400);
                    else BSET(SEG_918);
                    
                  }
               }
             }
              if(P1IN==0X7F)   
              { 
                Delay2();   
              }  
              else ;
              if(P1IN==0X7F)   
              { 
             Delay2();
              }
              else ;
           
            sys_mode++;
             xl3=4;
             if(xl2==0)
             {
               v=(int)ph_offset1;//(int)ph_offset2; 
            
                 xl2=0;;
            
             if(v>=0)
              x11=v;
             else 
             {
               x11=v;
             v=v*(-1);
             }
             cound_mv();
             _LCDCLR;
             DisplayMea(); 
             if(x11>=0)
               ;
             else BSET(SEG_BAR1);
             if(xl2==1)
             {
               if(x11<10 && x11>-10)
                  LCDMEM[8]=digit[0]; 
               else ;
             }
             else
             {
               if(x11<10 && x11>-10)
                  LCDMEM[8]=digit[0]; 
               else ;
             }
             LCDMEM[2]=digit[0]; 
             LCDMEM[1]=digit[15];    
             LCDMEM[0]=digit[5];
              // DisplayTemp(); 
             BSET(SEG_P3);
             BSET(SEG_mV);
           
                
                if(buff==0)
                { 
                  BSET(SEG_700);
                
                }
                else
                { 
                  BSET(SEG_686);
                
                  
                }   if(P1IN==0X7F)   
              { 
                Delay2();   
              }  
              else ;
              if(P1IN==0X7F)   
              { 
             Delay2();
              }
              else ;
             }
             
             else ;
            
             
             
             if(v>=0)
               ;
             else 
             {
               x11=v;
               v=v*(-1);
             }
               
             /*  BSET(SEG_C  );
               if(atc==1)                
                 BSET(SEG_MAN );
                else BSET(SEG_ATC );  */ 
              // Delay2(); 
              xl3=5; 
              sys_mode--;
              }
               else
               {
                 if(xl3==4)
                   sys_mode--;
                 else ;
                 P1IFG=0;   
                 xl3=0;//sumd6=0;
                // Delay(); 
                 key_v=0;
                 key=0;
                 v=ph;
                 break;
               }
             }
            
           }
           else 
           {
             key_v=0;
             P1IFG=0; 
             if(hold==2)
               hold=0;
             else ;//hold=1;            
             xl3=0;//sumd6=0;
           
           } 
           }
           else ;
         }
       }
       else ;
     }
    if(key_r==0)
      P1IE |= 0Xff;
    else ;
   
    if(sumd2<10)
    {
      if(key_r==0)
      {
        WDTCTL =WDT_ADLY_250;
        IE1 |= WDTIE;     
        LPM3;       
        WDTCTL =WDT_ADLY_250;
        IE1 |= WDTIE;     
        LPM3;
     }
      else 
      { 
         WDTCTL =WDT_ADLY_250;
        IE1 |= WDTIE;     
        LPM3;       
      /*   WDTCTL =WDT_ADLY_250;
        IE1 |= WDTIE;     
        LPM3;     
       WDTCTL =WDT_ADLY_16;
        IE1 |= WDTIE;     
        LPM3;
         WDTCTL =WDT_ADLY_16;
        IE1 |= WDTIE;     
        LPM3;  WDTCTL =WDT_ADLY_16;
        IE1 |= WDTIE;     
        LPM3;
         WDTCTL =WDT_ADLY_16;
        IE1 |= WDTIE;     
        LPM3;  WDTCTL =WDT_ADLY_16;
        IE1 |= WDTIE;     
        LPM3;
         WDTCTL =WDT_ADLY_16;
        IE1 |= WDTIE;     
        LPM3;  WDTCTL =WDT_ADLY_16;
        IE1 |= WDTIE;     
        LPM3;
         WDTCTL =WDT_ADLY_16;
        IE1 |= WDTIE;     
        LPM3;  WDTCTL =WDT_ADLY_16;
        IE1 |= WDTIE;     
        LPM3;
         WDTCTL =WDT_ADLY_16;
        IE1 |= WDTIE;     
        LPM3;*/
      }
    }
    else
    {
      WDTCTL =WDT_ADLY_16;
      IE1 |= WDTIE;     
      LPM3;    
    }
    sumd1++;
  
  }
  
}
/*****************************************************************************/
#pragma vector=WDT_VECTOR
__interrupt void watchdog_timer(void)
{ 
  WDTCTL =WDTPW +WDTCNTCL+ WDTHOLD;
  IE1 &= ~ WDTIE;
  LPM3_EXIT;  
  return;
}
/******************************************************************************/



