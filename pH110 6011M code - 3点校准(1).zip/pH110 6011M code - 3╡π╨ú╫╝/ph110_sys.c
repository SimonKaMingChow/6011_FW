 int v_data[51];
 int temp_data[51];
 char  atc_data[50] ; 
 char  mode_data[50] ; 
 
 char  buff_data[50];
 char  point_data[50];
   
// int data_d[7][50]={1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1};
float r30k=0;
float r10k=0;
float r1k=0; 
float mv_k1=0;
float mv_b1=0; 
float mv_k2=0;
float mv_b2=0;
float k_r1=0;
float b_r1=0;
float k_r2=0;
float b_r2=0;
///////////////////////////////////////////////////////////////////////////////

void delteall(void)                           //
{
   char i;/*,j=0,*flash_ptr;     
   flash_ptr = (char *)0xfa00;    
   FCTL1 = FWKEY +ERASE;                          //����FLASH��   
   FCTL3 = FWKEY; 
   flash_ptr = 0;                           //��������  
   FCTL1 = FWKEY +WRT;  
   flash_ptr = (int *)0xfa00;
   FCTL1 = FWKEY;
   FCTL3 = FWKEY +LOCK;
   flash_ptr = (char *)0xfc00;  
   FCTL1 = FWKEY +ERASE;                          //����FLASH��   
   FCTL3 = FWKEY; 
   flash_ptr = 0; 
   FCTL1 = FWKEY +WRT; 
  flash_ptr = (int *)0xfc00;
   FCTL1 = FWKEY;
   FCTL3 = FWKEY +LOCK;*/
 /*  
  int *flash_ptr=0;
  flash_ptr = (int *)0xc000;                   //д���    
  FCTL1 = FWKEY +ERASE;                           //����FLASH��    
  FCTL3 = FWKEY;
  *flash_ptr = 0;                           //��������
  FCTL1 = FWKEY +WRT;   
  flash_ptr = (int *)0xc200;
  FCTL1 = FWKEY;
  FCTL3 = FWKEY ;
  flash_ptr = (int *)0xc400;                   //д���    
  FCTL1 = FWKEY +ERASE;                           //����FLASH��    
  FCTL3 = FWKEY;
  *flash_ptr = 0;                           //��������
  FCTL1 = FWKEY +WRT;   
  flash_ptr = (int *)0xc600; 
  FCTL1 = FWKEY;
  FCTL3 = FWKEY +LOCK;
   flash_ptr = (int *)0xc800;                   //д���    
  FCTL1 = FWKEY +ERASE;                           //����FLASH��    
  FCTL3 = FWKEY;
  *flash_ptr = 0;                           //��������
  FCTL1 = FWKEY +WRT;   
  FCTL3 = FWKEY +LOCK;
  flash_ptr = (int *)0xca00;                   //д���    
  FCTL1 = FWKEY +ERASE;                           //����FLASH��    
  FCTL3 = FWKEY;
  *flash_ptr = 0;                           //��������
  FCTL1 = FWKEY +WRT; 
  FCTL3 = FWKEY +LOCK; */
 for(i=0;i<50;i++)
 {
   v_data[i]=0;
  temp_data[i]=0;
  mode_data[i]=0;  
  atc_data[i]=0; 
  buff_data[i]=0; 
  point_data[i]=0;  
 }
  
  
  
  
  
  return;
}
//==============================================================================
void Readdata_a(void)                           //���������������
{
   
   float *flash_ptr; 
   flash_ptr = 0; 
   flash_ptr = (float*)0x1000;
   ph_offset1 = *flash_ptr++;
   slope1= *flash_ptr++;
   ph_offset2 = *flash_ptr++;
   slope2= *flash_ptr++;
   ph_offset3 = *flash_ptr++;
   slope3= *flash_ptr++;
   temp_man=(int) *flash_ptr++;
   point=(char) *flash_ptr++;
   buff= (char)*flash_ptr++; 
   measing=(char)*flash_ptr++ ;
   sys_mode=(char)*flash_ptr++ ;
   sumd=(char)*flash_ptr++;  
   v1= *flash_ptr++;
   ph1=*flash_ptr++;  
   sumd7=(char)*flash_ptr++; 
   cal_ok=(char)*flash_ptr++;
   cal=(char)*flash_ptr++;
   v3=*flash_ptr++;
   v_cal=*flash_ptr++;
   v1=*flash_ptr++;
   ph1=*flash_ptr++;
   return;
}
//======================================================================================
void Savedata_a()
{ 
   float *flash_ptr; 
   flash_ptr = (float *)0x1000;    
   FCTL1 = FWKEY +ERASE;                          //����FLASH��   
   FCTL3 = FWKEY;
   *flash_ptr = 0.0;                                 //��������
   FCTL1 = FWKEY +WRT;  
   flash_ptr = (float*)0x1000;
   *flash_ptr++= ph_offset1;
   *flash_ptr++= slope1;
   *flash_ptr++= ph_offset2;
   *flash_ptr++= slope2;
   *flash_ptr++= ph_offset3;
   *flash_ptr++= slope3;
   *flash_ptr++= temp_man;
   *flash_ptr++= point;
   *flash_ptr++= buff;
   *flash_ptr++= measing;
   *flash_ptr++ = sys_mode;
   *flash_ptr++ =sumd;
   *flash_ptr++ =v2;
   *flash_ptr++ =ph2;
   *flash_ptr++ = sumd7;
   *flash_ptr++=cal_ok; 
   *flash_ptr++=cal;
   *flash_ptr++=v3;
   *flash_ptr++=v_cal;
   *flash_ptr++=v1;
   *flash_ptr++=ph1;
   FCTL1 = FWKEY;
   FCTL3 = FWKEY +LOCK;
   return;
}
//================================================================================
void Copy_a2b()
{
 /*  signed int *flash_ptra; 
   signed int *flash_ptrb; 
   unsigned int i;
   flash_ptra = (int *)0xe000;                //д���  
   flash_ptrb = (int *)0xc000;                //д���  
   FCTL1 = FWKEY +ERASE;                           //����FLASH��  
   FCTL3 = FWKEY;
   *flash_ptra = 0;                           //��������  
   FCTL1 = FWKEY +WRT;  
   for(i=0;i<512;i++)
   {
     *flash_ptra ++ =*flash_ptrb++;
   } 
   FCTL1 = FWKEY;
   FCTL3 = FWKEY +LOCK; */
   return;
}
///////////////////////////////////////////////////////////////////////////////
void Copy_a2bchar()
{
 /*  char *flash_ptra; 
   char *flash_ptrb; 
   unsigned int i;
   flash_ptra = (char *)0xe800;                //д���  
   flash_ptrb = (char *)0xc800;                //д���  
   FCTL1 = FWKEY +ERASE;                           //����FLASH��  
   FCTL3 = FWKEY;
   *flash_ptra = 0;                           //��������  
   FCTL1 = FWKEY +WRT;  
   for(i=0;i<512;i++)
   {
     *flash_ptra ++ =*flash_ptrb++;
   } 
   FCTL1 = FWKEY;
   FCTL3 = FWKEY +LOCK; */
   return;
}
//================================================================================
void Savedatb()
{  
 /* unsigned char i;
  char *flash_ptr1,*flash_ptr2,*flash_ptr3;
 // signed int va,vb;
  signed int *flash_ptr,*flash_ptra,*flash_ptrb;   
  Copy_a2b();
  flash_ptr = (int *)0xc200;                //д���     
  flash_ptra = (int *)0xc000;                //д���         
  FCTL1 = FWKEY +ERASE;                     //����FLASH��    
  FCTL3 = FWKEY;
  *flash_ptr = 0; 
  *flash_ptra = 0;  
  FCTL1 = FWKEY +WRT;   //��������   
  for(i=0;i<=sumd;i++)
  {
    if(i>=sumd4)
    {
      if(i==sumd4)
        flash_ptra++;
      else ;
      *flash_ptr ++ =*flash_ptra++;
    }
    else *flash_ptr ++ =*flash_ptra++;
  } 
  flash_ptrb = (int *)0xc600;                //д���      
  flash_ptr = (int *)0xc400;                //д��� 
  for(i=0;i<=sumd;i++)
  {
    if(i>=sumd4)
      {
      if(i==sumd4)
        flash_ptrb++;
      else ;
      *flash_ptr ++ =*flash_ptrb++;
    } 
    else *flash_ptr ++ =*flash_ptrb++;
  }  
  FCTL1 = FWKEY;
  FCTL3 = FWKEY +LOCK;
  Copy_a2bchar();
  flash_ptr1 = (char *)0xca00;                //д���  
  flash_ptr2 = (char *)0xc800;                 //д��� 
  FCTL1 = FWKEY +ERASE;                           //����FLASH��                 
  FCTL3 = FWKEY;
  *flash_ptr1 = 0;                           //��������  
  FCTL1 = FWKEY +WRT;     
  for(i=0;i<=sumd;i++)
  {
    if(i>=sumd4)
    {
      if(i==sumd4)
        flash_ptr2++;
      else ;
      *flash_ptr1 ++ =*flash_ptr2++; 
    }
    else *flash_ptr1 ++ =*flash_ptr2++;
  }  
  flash_ptr3 = (char *)0xcf00;                 //д��� 
  flash_ptr1 = (char *)0xcd00;                //д��� 
  for(i=0;i<=sumd;i++)
  {
    if(i>=sumd4)
    {
      if(i==sumd4)
        flash_ptr3++;
      else ;
      *flash_ptr1 ++ =*flash_ptr3++; 
    }
    else *flash_ptr1 ++ =*flash_ptr3++;
  }  
  flash_ptr3 = (char *)0xd200;                 //д��� 
  flash_ptr1 = (char *)0xd000;                //д��� 
  for(i=0;i<=sumd;i++)
  {
    if(i>=sumd4)
    {
      if(i==sumd4)
        flash_ptr3++;
      else ;
      *flash_ptr1 ++ =*flash_ptr3++; 
    }
    else *flash_ptr1 ++ =*flash_ptr3++;
  }   
  flash_ptr3 = (char *)0xd600;                 //д��� 
  flash_ptr1 = (char *)0xd400;                //д��� 
  for(i=0;i<=sumd;i++)
  {
    if(i>=sumd4)
    {
      if(i==sumd4)
        flash_ptr3++;
      else ;
      *flash_ptr1 ++ =*flash_ptr3++; 
    }
    else *flash_ptr1 ++ =*flash_ptr3++;
  }  
   flash_ptr3 = (char *)0xda00;                 //д��� 
  flash_ptr1 = (char *)0xd800;                //д��� 
  for(i=0;i<=sumd;i++)
  {
    if(i>=sumd4)
    {
      if(i==sumd4)
        flash_ptr3++;
      else ;
      *flash_ptr1 ++ =*flash_ptr3++; 
    }
    else *flash_ptr1 ++ =*flash_ptr3++;
  }  
  flash_ptr1 = (char *)0xdc00;                //д���   
  *flash_ptr1 =(sumd-1);
  FCTL1 = FWKEY;
  FCTL3 = FWKEY +LOCK; */
  return;
}
//================================================================================
void Savedata()
{  
  unsigned char i;//,j,k,l;
  char *flash_ptr1,*flash_ptr2;//,*flash_ptr3;
 // signed int va,vb;
  int *flash_ptr;//,*flash_ptra,*flash_ptrb;   
  sumd3=sumd;
  if(sumd==0xff)
    ;
  else Copy_a2b();
  flash_ptr2 = (char *)0xbff0;                //д���   
  flash_ptr = (int *)0xc000;                //д���     
  flash_ptr1 = (char *)0xc800;                //д���        
  
   
  FCTL1 = FWKEY +ERASE;                           //����FLASH��    
  FCTL3 = FWKEY;
  *flash_ptr = 0; 
  *flash_ptr1 = 0;   
  *flash_ptr2 = 0; 
  FCTL1 = FWKEY +WRT;   //��������   
  if(sys_mode==MODE_pH || sys_mode==MODE_AUTO_pH  )
    v_data[sumd]=ph;
  else v_data[sumd]=mv/10;   
  temp_data[sumd]=temp1;
  //j=sumd;  
  mode_data[sumd]=sys_mode;
  atc_data[sumd]=atc; 
  buff_data[sumd]=buff; 
  point_data[sumd]=point; 
   for(i=0;i<=sumd3;i++)
  {
   *flash_ptr ++=v_data[i];
   *flash_ptr ++=temp_data[i];
   *flash_ptr1 ++= mode_data[i];  
   *flash_ptr1 ++= atc_data[i]; 
   *flash_ptr1 ++= buff_data[i]; 
   *flash_ptr1 ++= point_data[i];  
  }
  *flash_ptr1++ =sumd3;
  *flash_ptr2++ =sumd3;

/*
  for(i=0;i<=sumd3;i++)
  {
    if(i==sumd3)
      *flash_ptr ++ =va;
    else *flash_ptr ++ =*flash_ptra++;
  } 
  flash_ptrb = (int *)0xc400;                //д���      
  flash_ptr = (int *)0xc600;                //д��� 
  for(i=0;i<=sumd3;i++)
  {
    if(i==sumd3)
      *flash_ptr++ =vb;
    else *flash_ptr ++ =*flash_ptrb++;
  }  
  FCTL1 = FWKEY;
  FCTL3 = FWKEY +LOCK;
 if(sumd==0)
    ;
  else Copy_a2bchar();
  flash_ptr1 = (char *)0xc800;                //д���  
  flash_ptr2 = (char *)0xca00;                 //д��� 
  FCTL1 = FWKEY +ERASE;                           //����FLASH��                 
  FCTL3 = FWKEY;
  *flash_ptr1 = 0;                           //��������  
  FCTL1 = FWKEY +WRT;     
  for(i=0;i<=sumd3;i++)
  {
    if(i==sumd3)
      *flash_ptr1++ =k;  
    else *flash_ptr1 ++ =*flash_ptr2++;
  }  
  flash_ptr3 = (char *)0xcc00;                 //д��� 
  flash_ptr1 = (char *)0xce00;                //д��� 
  for(i=0;i<=sumd3;i++)
  {
    if(i==sumd3)
      *flash_ptr1++ =l;  
    else *flash_ptr1 ++ =*flash_ptr3++;
  }   
   flash_ptr3 = (char *)0xd000;                 //д��� 
  flash_ptr1 = (char *)0xd200;                //д��� 
  for(i=0;i<=sumd3;i++)
  {
    if(i==sumd3)
      *flash_ptr1++ =l;  
    else *flash_ptr1 ++ =*flash_ptr3++;
  }   
  flash_ptr3 = (char *)0xd400;                 //д��� 
  flash_ptr1 = (char *)0xd600;                //д��� 
  for(i=0;i<=sumd3;i++)
  {
    if(i==sumd3)
      *flash_ptr1++ =buff;  
    else *flash_ptr1 ++ =*flash_ptr3++;
  }     
  flash_ptr3 = (char *)0xd800;                 //д��� 
  flash_ptr1 = (char *)0xda00;                //д��� 
  for(i=0;i<=sumd3;i++)
  {
    if(i==sumd3)
      *flash_ptr1++ =point;  
    else *flash_ptr1 ++ =*flash_ptr3++;
  }   */
//  FCTL1 = FWKEY;
//  FCTL3 = FWKEY +LOCK; 
 /* flash_ptr2 = (char *)0xc900;                //д���   
   *flash_ptr2 = 0;  
   FCTL1 = FWKEY +WRT;   //��������   
  *flash_ptr2 =sumd;*/
  FCTL1 = FWKEY;
  FCTL3 = FWKEY +LOCK; 
  sumd++;
 // sumd3++;
  return;
}
////////////////////////////////////////////////////////////////////////////////

void Savedata_set()
{ 
   float *flash_ptr; 
   flash_ptr = (float *)0x1080;    
   FCTL1 = FWKEY +ERASE;                          //����FLASH��   
   FCTL3 = FWKEY;
   *flash_ptr = 0.0;                                 //��������
   FCTL1 = FWKEY +WRT;  
   flash_ptr = (float*)0x1080;
   *flash_ptr++= mv_k1;
   *flash_ptr++= mv_b1;
   *flash_ptr++= mv_k2;
   *flash_ptr++= mv_b2;
   *flash_ptr++= k_r1;
   *flash_ptr++= b_r1;
   *flash_ptr++= k_r2;
   *flash_ptr++= b_r2;
   *flash_ptr++= r10k;  
   *flash_ptr++= r1k;  
   FCTL1 = FWKEY;
   FCTL3 = FWKEY +LOCK;
   return;
}
//===============================================================================
void Readdata_set(void)                           //���������������
{
   
   float *flash_ptr; 
   flash_ptr = 0; 
   flash_ptr = (float*)0x1080;
   mv_k1 = *flash_ptr++;
   mv_b1= *flash_ptr++;
   mv_k2= *flash_ptr++;
   mv_b2= *flash_ptr++;
   k_r1= *flash_ptr++;
   b_r1= *flash_ptr++;
   k_r2= *flash_ptr++;
   b_r2= *flash_ptr++;
   r10k= *flash_ptr++;  
   r1k= *flash_ptr++; 
   return;
}

//===============================================================================


//==================================================================================
void sys(void)
{
  char *flash_ptr4;
  WDTCTL    = WDTPW + WDTHOLD;       //�ع�
  FLL_CTL0 |= XCAP14PF;              //���þ������
  SCFQCTL   = SCFQ_4M;               //����ʱ��Ƶ��  
  P1DIR &= 0Xff;                             //�������ŷ������� p1.0~p1.7
  P1IES = 0xff;                             //�½����ж�     
 // P1IE |= 0Xff;
  P1IFG = 0;  
  P2DIR = 0X0E; 
  P2OUT = 0X02;  
  LCDCTL = LCDON + LCD4MUX + LCDP1;
  BTCTL  = BTFRFQ1;
  SD16CTL   = SD16REFON + SD16SSEL_0;   //SD16VMIDON +   // 1.2V ref, SMCLK  ��׼�����ⲿ
 // SD16INCTL1 = SD16GAIN_1;
  SD16CCTL0 = SD16GRP;             // Single conv, group with CH1
  SD16CCTL1 = SD16GRP+SD16DF;             // Single conv, group with CH2
  SD16CCTL2 = SD16IE;              // Single conv, enable interrupt
  temp_man = 250;
  temp=0.0;
  set_ok=1;
  Readdata_set();
  Readdata_a();
  flash_ptr4 = (char*)0xc8f0;
  sumd = (char)*flash_ptr4++;
  if(sumd==0xff)
  {
    sumd=1;
    sumd3=1;
  }
  else sumd++;
  if(temp_man<=-1000)
    temp_man=250;
  else ;    
 key_set=0;
 if(cal==2)
   cal=1;
 else ;

  return;
}
////////////////////////////////////////////////////////////////////////////////////





