//deifne key************************                                                                                                  *****
#define  KEY_MODE      1                      //���� MODE
#define  KEY_POWER     2                        //���� ON/OFF
#define  KEY_DOWN      4                       //���� DOWN
#define  KEY_UP        8                       //���� UP
#define  KEY_SLOPE     0x10                       //���� SLOPE
#define  KEY_STAND     0x20                       //���� STAND
#define  KEY_CLEAR     0x40                       //���� CLEAR
#define  KEY_MEAS      0x80                       //���� MEAS


//------------------------------------------------------------------------------
//�������������ж�
//��  �ã��жϰ�������
//------------------------------------------------------------------------------
/*void InitKEY(void)
{
   P1DIR &= 0Xff;                             //�������ŷ������� p2.0~p2.4
   P1IES |= 0x00;                             //�½����ж�     
   P1IE |= 0Xff;
   P1IFG = 0;                                 //���־ ����IES�ı䵼����Ч�ж�

} */
/*
///////////////////////////////////////////////////////////////////////////////////
void Delay(void)                            //1s
{ 
  unsigned long int i; 
  for(i=0x7ffff;i>0;i--);
  return;
}
//////////////////////////////////////////////////////////////////////////////
void Delay1()                                       //250mS
{
  unsigned long int i;
  for(i=0x28f4;i>0;i--);
  return;
}
//////////////////////////////////////////////////////////////////////////////
void Delay2()                                       //500mS
{
  unsigned long int i;
  for(i=0x3ffff;i>0;i--);
  return;
}
/////////////////////////////////////////////////////////////////////////////
void Delay3()                                       //125mS
{
  unsigned long int i;
  for(i=0x147a;i>0;i--);
  return;
}*/
///////////////////////////////////////////////////////////////////////////////////
void Delay(void)                            //1s
{ 
  unsigned long int i,l=0,k=0;
  while(1)
    {  
     if(k>=500)
     {
       k=0;
       break;
     }
     else
     {
      while(1)
      {
        if(l>1000)
        {
          l=0;
          break;
        }
        else
        {
        for(i=0x7ffff;i>0;i--);
        l++;
        }
      }
      k++;
     }
    }
  return;
}
//////////////////////////////////////////////////////////////////////////////
void Delay1()                                       //250mS
{
  unsigned long int i,l=0,k=0;
  while(1)
    {  
     if(k>=20)
     {
       k=0;
       break;
     }
     else
     {
      while(1)
      {
        if(l>1000)
        {
          l=0;
          break;
        }
        else
        {
        for(i=0x7fffff;i>0;i--);
        l++;
        }
      }
      k++;
     }
    } 
  return;
}
//////////////////////////////////////////////////////////////////////////////
void Delay2()                                       //500mS
{
  unsigned long int l,j=0,k=0;
  while(1)
    {  
     if(k>=250)
     {
       k=0;
       break;
     }
     else
     {
      while(1)
      {
        if(l>1000)
        {
          l=0;
          break;
        }
        else
        {
        for(j=0;j<600;j++)
        {
          ;
        }     
        l++;
        }
      }
      k++;
     }
    }
  return;
}
/////////////////////////////////////////////////////////////////////////////
void Delay3()                                       //125mS
{
  unsigned long int l,j=0,k=0;
  while(1)
    {  
     if(k>=125)
     {
       k=0;
       break;
     }
     else
     {
      while(1)
      {
        if(l>1000)
        {
          l=0;
          break;
        }
        else
        {
        for(j=0;j<600;j++)
        {
          ;
        }     
        l++;
        }
      }
      k++;
     }
    }
  return;
}
/////////////////////////////////////////////////////////////////////////////
void Delay4()                                       //125mS
{
  unsigned long int l,j=0,k=0;
  while(1)
    {  
     if(k>=1)
     {
       k=0;
       break;
     }
     else
     {
      while(1)
      {
        if(l>1000)
        {
          l=0;
          break;
        }
        else
        {
        for(j=0;j<600;j++)
        {
          ;
        }     
        l++;
        }
      }
      k++;
     }
    }
  return;
}
/////////////////////////////////////////////////////////////////////////////
void buzz(void)
{
  _BUZ_ON;
  Delay1();
  _BUZ_OFF;
  return;
}
/////////////////////////////////////////////////////////////////////////////////
void buzz1(void)
{
  if(key_v==0)//KEY_MODE )
   ;
  else
  {
    if(key_v==KEY_STAND)
       ;       
    else if(key_v==KEY_SLOPE)
      ;
    else if(key_v==KEY_UP || key_v==KEY_DOWN)
    {
      if(measing==0 )
      {
        if(atc==1)
        {
          if(hold==1)
          {
            if(sys_mode==MODE_AUTO_pH)
            {
              if(point==0 || cal==2)
                buzz();
              else ;
            }
            else ;
          }
          else buzz();
        }
        else ;
      }
      else buzz();
    }
    else buzz();
  }
  //else if(key_v==KEY_POWER)
  //   buzz();


/* if(measing==0 || measing==3 || measing==4)
 {
   if(measing==0|| measing==4)
   {
     if(hold==1)
     {
       if(P1IFG==0x04 || P1IFG==0x08|| P1IFG==0x0C)
       {
         if(sys_mode==MODE_pH ||sys_mode==MODE_AUTO_pH) 
         {
          // if(slope2==0)
           //  buzz();
          // else ;
             
         }
         else ;
       }
       else buzz();
     }
     else
     {
     if(P1IFG==0x20)
       ;
     else buzz();
     }
   }
   else buzz();
 }
 else if(measing==1 || measing==2)
 {
   if(P1IFG==0x80 || P1IFG==0x20 || P1IFG==0x10)
     ;
   else 
   {
     if(measing==1)
     {
       if(recal==0)
       {
         if(P1IFG==0x04 || P1IFG==0x08 )
           ;
         else 
         {
           if(P1IFG==0x01 || P1IFG==0x02 ||P1IFG==0x40 )
             buzz();
           else ;
         }
         
       }
       else buzz();
     }
     else ;
     if(measing==2)
     {
       if(delte==0)
       {
          if(P1IFG==0x04 || P1IFG==0x08 )
           ;
         else
         {
           if(P1IFG==0x01 || P1IFG==0x02 ||P1IFG==0x40 )
             buzz();
           else ;
         }
       }
       else  buzz();
     }
     else ;
   }
   
 }
 else if(measing==5)
 {
   if(P1IFG==0x01 || P1IFG==0x02 )
     buzz();
   else ;
 }
 else ;*/
 return;
}
//------------------------------------------------------------------------------
//�������������ж�
//��  �ã��жϰ�������
//------------------------------------------------------------------------------
#pragma vector =PORT1_VECTOR
__interrupt void port1 (void)     //�����ж� ������
{ 
  P1IE = 0x00; //P1IE &= ~ 0Xff;  
  Delay1(); // Delay4();
  key_v =  P1IFG; 
  if(P1IN ==0xff)
   key_v =0 ;
  else 
{
  key=1;
 
  buzz1();
  }  
  P1IFG=0;
  if(power==1)
  {
    if(key_v==0x02)
    {
      LPM3_EXIT;//Readdata_a();
      measing=mode;
      key_v=0;
      hold=0;
    }
    else if(key_v==0x22)
    { 
      if(measing==6 )
      {
        if(sys_mode==0 || sys_mode==2)
        { 
          LPM3_EXIT;
          measing=mode;     
          if(buff==0)
            buff=1;
          else buff=0;
          key_v=0;
          hold=0;
        }
        else P1IE |= 0X02;
      }
      else P1IE |= 0X02;
    }
    else P1IE |= 0X02;
  }
  else ;
  return;
}
//------------------------------------------------------------------------------
//������������
//��  �ã���Ӧ�����¼�
//------------------------------------------------------------------------------
void NoKey(void)
{  
  autoff++;
  if(autoff >1100)//3360)//3900)
  {
    autoff = 0;   //�ػ�����  30�����ް����Զ��ػ�
    measing=6;
    //sys_mode = MODE_OFF;                             //�ػ�
  }
  else 
  {
    if(key_set==1)
      sys_mode =3;
    else ;
  }  
  key=0;
//  sumd2=0;
  return;
}
//--------------------------------------
void KeyPower(void)
{
 /*
  if(sys_mode == MODE_OFF)
  {
    //sys_mode=measing;//sys_mode = 0;
    key_v=0;
  }
  else 
  {
    if(sys_mode==MODE_CAL)
      ;
    else measing=sys_mode;*/
    
      mode=measing;
      measing = 6;
  
  return;
}
//--------------------------------------
void KeyEnter(void)
{     
  char *flash_ptr4;
  
   if(measing==1)
   { 
     flash_ptr4 = (char*)0xfcff;//0xfcc8;
     sumd = (char)*flash_ptr4++;
     if(sumd==0xff|| sumd==0)
     {
       recal=2;
       sumd=0;
     }
     else
     {
       recal=1;
       sumd4=sumd;
     }
   }
   else if(measing==2)
   {    
     flash_ptr4 = (char*)0xfcff;//0xfcc8;
     sumd = (char)*flash_ptr4++;
     if(delte==0)
     {
       delte=1;
       if(sumd==0xff)
         sumd=1;
       else ;
       sumd4=sumd;
     }
     else if(delte==1)
       delte=2;
     else if(delte==2)
       delte=3;
     else ;
   }
   else
   {
     if(clear==1)
     {
      ;
     }
     else
     {
     delte=0;
     if(cal==0)//measing==0)
     {
       if(error==0)
         measing=3;
       else ;
     }
     else ;
     }
   }
   return;
}
//--------------------------------------
void KeyMode(void)
{ 
  hold=0;
  sumd1=0;
  each=1;  
  if(key_set==1)
  {
    set_i++;
    mode=MODE_SET; 
  }
  else 
  {    
    if(measing==0 || measing==4)   
    {
      if(measing==4)
        ;
      else sys_mode ++; 
      if(sys_mode>3)
      {
        if(measing==4) //�޸�
        {
          measing=0;
         // if(error==0)
          Readdata_a();
         //else 
          //Readdata_b();
          if(point==0)
            ;
          else cal_ok=1;
         // sys_mode --;
          error=0;
          cal=0;
         }
        else measing++;
        
      }
      else  
      {
        if(cal==0)
          ;
        else
        { Readdata_b();//if(error==0)
         // Readdata_a();
         // else Readdata_b();
        /*  if(measing==4)
          point--;
         else ;
          */
            if(point==0)
            ;
          else  cal_ok=1;
            cal=0;error=0;
        }//sys_mode -- ;
        if(sys_mode>3)
            sys_mode=0;
        else ;
        measing=0;
      }
   Savedata_a();   
    }
    else 
    {
      if(measing<2)
      {sys_mode =0;
        if(measing==1)
        {
          if(recal==1 ||recal==2)
          {
            Readdata_a();
            recal=0;
            sumd4=sumd;
            sumd++;
          }
          else measing++;
        }
        else  measing++;
      }
    
      else 
      {
       
        if(delte==0)
        {Readdata_a();
          measing=0;
          sys_mode=0;
        }
        else
        {
          if(delte==1 )
            sumd++;
          if(delte==2)
          {
          if(each==0)
            ;
          else sumd++;
          
          }
          else ;
          delte=0;
        }
      }
    }
    
     
  }
  return;
}
//-------------------------------------------------------------------
void KeyMeas(void)
{
  if(measing==0|| measing==4)
  {
  if(hold==1)
    hold=0;
  else ;
  sumd1=0;
 // if( point==2)
 //   sumd7=1;
 // else ;
  }
  else ;
  
  return;
}
//------------------------------------------------------------------------------
void KeyStand(void)
{
  if(measing==0 || measing==4)
  {
  if(sys_mode==MODE_pH ||sys_mode==MODE_AUTO_pH) 
  {
    if(P1IN==0XDF)
    {
      Delay();
      if(P1IN==0XDF)
      { 
        buzz();  
     /*   if(sys_mode==MODE_AUTO_pH)
      {  Adc();
        Count();    //������� 
        }
      else ;*/
        measing=4;
        //sys_mode=MODE_CAL;
        sumd1=0;
        hold=0;
        point=1;
        cal=1;cal_ok=0;
        sumd7=0; 
        if(buff==0)
       {
         if(mv>900 && mv<=1100) // if(mv>2400.0 || mv<-2400.0)//if(mv>900.0 || mv<-900.0)
           error=1;
         else if(mv<-900 && mv>=-1100)
           error=1;
         else if(mv>2600.0)
           error=1;
         else if(mv<-2600.0)
           error=1;
         else if(temp1>600.0 || temp1<0.0)
           error=3;
         else error=0;
       }
       else
       {
          if(mv>983 && mv<=1100) // if(mv>2400.0 || mv<-2400.0)//if(mv>900.0 || mv<-900.0)
           error=1;
         //else if(mv<-900 && mv>=-1100)
          // error=1;
         else if(mv>2600.0)
           error=1;
         else if(mv<-1900.0)
           error=1;
         else if(temp1>600.0 || temp1<0.0)
           error=3;
         else error=0;
       }
      }
      else ;
    }
    else ;
    
   
  }
  else ; 
  }
  else ;
  return;
}
//------------------------------------------------------------------------------
void KeySlope(void)
{
  if(sumd7==0)
  {
  if(measing==0 || measing==4)
  {
  if((point<=3) && sumd7==0 )
  {
    if(sys_mode==MODE_pH ||sys_mode==MODE_AUTO_pH) 
    {
      if(point>=1 && cal!=1 )
      {
      
     // sys_mode=MODE_CAL;
      sumd1=0;
         buzz();
     //   Adc(); // ;    Adc();   Adc();                                 //ADת������
     // Delay();//  delay(100);
    if(hold==1)//if(sys_mode==MODE_AUTO_pH)
      { 
      //  Adc();Adc();Adc();Adc();Adc();Adc();Adc();Adc();
      //  Count();    //�������  
    //  mV();  
  // Lobat();
        Count();    //�������  
     
     }
      else ;
     hold=0;
        if(point==1)
        { 
          if(buff==0)
           {
             if(v1>900.0 || v1<-900.0)
              ;
             else {cal_ok=0;
               point=2;measing=4; cal=1;cal_ok=0;//
             }
           }
           else
           {
              if(v1>983.0 || v1<-817.0)
               ;
             else {cal_ok=0;
               point=2;measing=4; cal=1;cal_ok=0;//
             }
           } //v_cal=mv;
        }
        else if(point==2)
        {  measing=4;//cal_ok=0;
          if(mv>=v_cal)
          {
            if(mv-v_cal>600)
               point=3;
            else  point=2;
          }
          else
          {
              if(v_cal-mv>600)
               point=3;
            else  point=2;
          }
       /*   if(v_cal>=0 && mv>=0)
            point=2;
          else if(v_cal>=0 && mv<=0)          
            point=3; 
          else if(v_cal<=0 && mv<=0)          
            point=2;
          else point=3;*/
          cal=1;cal_ok=0;
        }
        else 
        {
          if(v3>=0 && mv>=0)
            point=3;
          else if(v3>=0 && mv<=0)          
            error=2; 
          else if(v3<=0 && mv<=0)          
            point=3;
          else error=2;
          cal=1;  measing=4;cal_ok=0;
        }
    //  cal=1;//
      }
      else ;
    }
    else ;
  }
  else key_v=0;
  }
  }
  else ;
  return;
}
//-----------------------------------------------------------------------------
void KeyUp1(void)
{
 
//  if(hold==0)
//  {
    sumd1=0;
    ++temp_man;
    if(sumd2>=10)
      sumd2=10;
    else sumd2++;
    if( sys_mode==1|| sys_mode==3)
    {
    if(temp_man>1200)
      temp_man=-100;
    else ;
    }
    else
    {
      if(cal==0)
      {
      if(temp_man>1200)
            temp_man=-100;
          else ;
      }
      else
      {
        if(temp_man>600 || temp_man<0)
      temp_man=0;
      else ;
         
            
      }
    }
 // }
//  else ;
    /*
  {
    if((sys_mode==0 || sys_mode==2 ||sys_mode==7) && cal_ok==0)
    {
      sumd1=0;
      ++temp_man;
      if(sumd2>=10)
        sumd2=10;
      else sumd2++;
      if(cal==0 || sys_mode==1 )
      {
      if(temp_man>1200)
        temp_man=-100;
      else ;
      }
      else
      {
        if(temp_man>600)
        temp_man=0;
        else ;
      }
    }
    else ;
      
    
  }*/
  return;
}
//-----------------------------------------------------------------------------
void KeyUp(void)
{ 
  if(measing==1)
   {
     hold=0; 
     sumd4++;     
  
       if(sumd4>50)
         sumd4=1;
       else 
       {
         if(sumd4>sumd)
           sumd4=1;
         else ;
       }
   }
  else if(measing==2)
  {
    if(delte==2)
    {
     hold=0; 
     sumd4++;
     if(sumd4>50)
         sumd4=1;
       else 
       {
         if(sumd4>sumd)
           sumd4=1;
         else ;
       }
    }
    else if(delte==1)
    {
      if(each==1)
        each=0;
      else each=1;
    }
  }
  else
  {
    if(measing==0 || measing==4)
    {
    if(atc==1)
    {
       KeyUp1();/*
    if(sumd2>10)
      ;
    else KeyUp1();*/
    }
    else ;
    }
    else ;
  }
  return;
}

//------------------------------------------------------------------------------
void KeyDown1(void)
{  
 
 // if(hold==0)
 // { 
   
    sumd1=0;
    --temp_man;
    if(sumd2>=10)
      sumd2=10;
    else sumd2++;
    if( sys_mode==1|| sys_mode==3)
    {
    if(temp_man<-100)
      temp_man=1200;
    else ;
    }
    else
     {
      if(cal==0)
      {if(temp_man<-100)
            temp_man=1200;
          else ;

      }
      else
      {
      
          if(temp_man<0 || temp_man>600)
            temp_man=600;
          else ;
     
      }
    }
//  }
 // else ;
    /*
  {
    if((sys_mode==0 || sys_mode==2 ||sys_mode==7) && cal_ok==0)
    {
      sumd1=0;
      --temp_man;
      if(sumd2>=10)
        sumd2=10;
      else sumd2++;
      if(cal==0 || sys_mode==1)
      {
      if(temp_man<-100)
        temp_man=1200;
      else ;
      }
      else
      {
        if(temp_man<0)
        temp_man=600;
        else ;
      }
    }
    else ;
      
    
  }*/
  return;
}
//-------------------------------------------------------------------------------
void KeyDown(void)
{  
  if(measing==1)
   {
     hold=0;  
     sumd4--;
    
     if(sumd4<1)
     {
       sumd4=sumd;
       if(sumd4>50)
         sumd4=50;
       else ;
     }
     else;
   }
  else if(measing==2)
  {
    if(delte==2)
    {
     hold=0; 
     sumd4--;
      if(sumd4<1)
     {
       sumd4=sumd;
       if(sumd4>50)
         sumd4=50;
       else ;
     }
     else;
    }
    else if(delte==1)
    {
      if(each==1)
        each=0;
      else each=1;
    }
    
  }
  else  
  {
    if(measing==0||measing==4)
    {
    if(atc==1)
    {
      KeyDown1();
 
    }
    else ;
    }
    else ;
  } 
  return;
}
//------------------------------------------------------------------------------
//�������� KeyDeal
//��  �ã� ������������
//------------------------------------------------------------------------------
void KeyDeal(void)
{    
   if(key_v != 0)           //�м����� �Զ��ػ���ʱȡ��
     autoff = 0;
   else 
   {
     if(set_ok==1)
       ;
     else autoff = 0;
   }  
   if(measing==0 || measing==4)
   {
    
       if(P1IN !=0XFF)
       {     
         if(P1IN==0XBF)
         {
           if(measing==0 || measing==4)
           {
             if(error==0)
             {
               while(1)               
               {
                 if(sumd6==5)
                 {
                   P1IE &= ~ 0Xff; 
                   clear=1;
                   sumd6=0;
                   key_v=0;
                   break;
                 }
                 else 
                 {
                   if(P1IN==0XBF)
                   {
                     sumd6++; 
                     Delay3();
                   }
                   else
                   {
                     sumd6=0;
                     break;
                   }
                 }
               }
             }
             else
             {
               clear=1;
               key_v=0;
             }
           }
         else sumd6=0;
         }
         else sumd6=0;     
       }
       else sumd6=0;
     
   }
   else ; 
   if(measing==0|| measing==4)
   {
   if(atc==1)
   {
     if(key_v==0)
     {
       if(P1IN !=0XFF)
       {     
         if(P1IN==0XF7)
           key_r=1;
         else if(P1IN==0XFB)
           key_r=2;
         else key_r=0;
       }
       else 
       {
         key_r=0;
         sumd2=0;
       }
     }
     else 
     {
       key_r=0;
       sumd2=0;
     }
   }
   else key_r=0;
   if(hold==1)
   {
     if(sys_mode==0 || sys_mode==2)
     {
       if(cal==0)
       {
         
         if(point==0)
         {
           if(key_r==1)
           {
             KeyUp1();
             buzz();
           }
           else if(key_r==2)
           {
             KeyDown1();
             buzz();
           }
           else sumd2=0;
         }
         else 
         {
           if(key_v==KEY_DOWN || key_v==KEY_UP)
           key_v=0; 
           else ;
         }
       }
       else
       {
         if(key_r==1)
         {
           KeyUp1();
           buzz();
         }
         else if(key_r==2)
         {
           KeyDown1();
           buzz();
         }
         else sumd2=0;
       }
     }
     else ;
   }
   else 
   {
     if(key_r==1)
     {
       KeyUp1();
       buzz();
     }
     else if(key_r==2)
     {
       KeyDown1();
       buzz();
     }
     else sumd2=0;
   }
   }
   else ;
   switch(key_v) 
     {
      
     case 0     :   NoKey();        break; 
     case 1     :   KeyMode();      break; 
     case 2     :   KeyPower();     break;
     case 4     :   KeyDown();      break;  
     case 8     :   KeyUp();        break;     
     case 16    :   KeySlope();     break;
     case 32    :   KeyStand();     break;
     case 64    :   KeyEnter();     break;  
     case 128   :   KeyMeas();      break;
    
     }
  if(atc==1)
  {
   if(P1IN==0XF3)
   {
     if(hold==0)
     {
       temp_man= 250;
       buzz();
     }
   }
   else ;
  }
  else ;
   if((P2IN & 0x0f)==0X02)
    {
      set_ok=0;
      set_i=0;
      key_set=1;//sys_mode=MODE_SET;
      measing=5;
      buzz();
      error=0;
      RANGE=0;ai=0;
      RANGE_TEMP=0;
    }
    else ;
  key_v=0;
  return;
} 
///////////////////////////////////////////////////////////////////////////////
