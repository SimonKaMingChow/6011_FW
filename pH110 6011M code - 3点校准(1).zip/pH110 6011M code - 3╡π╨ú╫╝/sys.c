//******************************************************************************
//sys�ļ� ����
//******************************************************************************




//------------------------------------------------------------------------------
//��������λ�������� 
//��  �ã���λ ���� ����
//------------------------------------------------------------------------------
void _bSET(char * address,unsigned char bit)                                    //��λ
{
    *address|=bit;
}

void _bCLR(char * address,unsigned char bit)                                    //����
{
    *address&=(~bit);
}

/*******************************************************************************
FLASH����
FLASH�Ķ�д ���������������
*******************************************************************************/
void SaveDataA(void)                                                            //д����Ҫ���������
{
  char i;                           
  float *flash_ptr;
  flash_ptr = (float *)0x1080;                                                  //д��A��
  FCTL1 = FWKEY +ERASE;                                                         //����FLASH��    
  FCTL3 = FWKEY;
  *flash_ptr = 0;                                                               //��������
  FCTL1 = FWKEY +WRT;
  
 
  *flash_ptr++ = con_ref_v;                                                     //д������
  *flash_ptr++ = tem_ref_v;
  *flash_ptr++ = tem_k;
  *flash_ptr++ = tem_b;
  
  for(i=1;i<SET_POINT;i++)
  {
  *flash_ptr++ = con_k[i];
  *flash_ptr++ = con_b[i];
  }
  
  for(i=0;i<SET_POINT;i++)
  {
   *flash_ptr++ = con_f[i];
  }

  FCTL1 = FWKEY;
  FCTL3 = FWKEY +LOCK;
}

void SaveDataB(void)
{                        
  float *flash_ptr;
  flash_ptr = (float *)0x1000;                                                  //д��B��
  FCTL1 = FWKEY +ERASE;
  FCTL3 = FWKEY;
  *flash_ptr = 0;
  FCTL1 = FWKEY +WRT;
         
  *flash_ptr++ = std_kh;   
  *flash_ptr++ = std_kl; 
  *flash_ptr++ = std_hok;
  *flash_ptr++ = std_lok;
  
  
  FCTL1 = FWKEY;
  FCTL3 = FWKEY +LOCK;
}
/////////////////////////////////////////////////////////////////////////////
void ReadData(void)                                                             //���������������
{
   char i;
   float *flash_ptr;
   flash_ptr = (float *)0x1080;
    

   con_ref_v = *flash_ptr++;
   tem_ref_v = *flash_ptr++;     
   tem_k = *flash_ptr++;
   tem_b = *flash_ptr++;
   
  for(i=1;i<SET_POINT;i++)
  {
    con_k[i] = *flash_ptr++;
    con_b[i] = *flash_ptr++;
  }
  
   for(i=0;i<SET_POINT;i++)
  {
    con_f[i] = *flash_ptr++ ; 
  }
 //  ��ȡУ��ϵ��---------------------------------------------------------------------------------
   flash_ptr = (float *)0x1000;
  
   std_kh = *flash_ptr++;
   std_kl = *flash_ptr++;
   std_hok = *flash_ptr++;
   std_lok = *flash_ptr++;
  
   
   
 //  if((std_k>1.5)||(std_k<0.5)) std_k = 1;     //flash��������˷Ƿ����� �򸶳�ֵ1��

}

*******************************************************************************/
//��ʱ����
/*******************************************************************************/
void Delay(unsigned int n)
{
   unsigned int i=0;
   for(;n>0;n--)
   {
      for(i=0;i<50000;i++)
      {
        ;
      }
   }
}
/*

void Bat(void)
{   
   P2DIR &= ~BIT5;
   
   if( P2IN & BIT5)
   {
    _bCLR(SEG_BAT);
   }
  else
  {
  
    // bat_flash++;
    // if(bat_flash & BIT1)
    // {
       _bSET(SEG_BAT);
   //  }
   //  else
   //  {
   //    _bCLR(SEG_BAT);
   //  }
  }
}
*/
